import datetime
import json
from pathlib import Path
import sqlite3
import subprocess

baseline = "e7cd3a95c5163f6e973187a24aab002f5e5c351b"
worktree = Path("/home/user/.codex/worktrees/independent-sol-audit/mn-molecular-design-studio")
development = Path("/home/user/programs/git-projects/mn-molecular-design-studio")
identifiers = ("20261111-172829-e9cd2cd2", "20261111-172856-874abe10")
results = Path("/mnt/data/RESULTS/mn-molecular-design-studio/workdir/runs")
record = {
    "checked_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "baseline": baseline,
    "worktree_head": subprocess.check_output(["git", "-C", str(worktree), "rev-parse", "HEAD"], text=True).strip(),
    "worktree_tracked_changes": subprocess.check_output(["git", "-C", str(worktree), "diff", "--name-only", "HEAD"], text=True).splitlines(),
    "development_head": subprocess.check_output(["git", "-C", str(development), "rev-parse", "HEAD"], text=True).strip(),
    "development_status": subprocess.check_output(["git", "-C", str(development), "status", "--short"], text=True).splitlines(),
    "audit_directories_remaining_in_production_results": [identifier for identifier in identifiers if (results / "analysis" / identifier).exists()],
}
for filename, table, column in (("job_catalog.sqlite3", "jobs", "run_id"), ("molecular_library.sqlite3", "molecular_ingestions", "source_key")):
    path = Path("/home/user/.local/share/mn-molecular-design-studio/database") / filename
    connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        record[filename + "_audit_rows"] = [row[0] for identifier in identifiers for row in connection.execute(
            f"SELECT {column} FROM {table} WHERE {column} LIKE ?", ("%" + identifier + "%",))]
    finally:
        connection.close()
record["service_state"] = subprocess.check_output([
    "systemctl", "--user", "show", "studio-api.service", "studio-ui.service", "--property=Id,MainPID,ActiveState"
], text=True)
assert record["worktree_head"] == baseline
assert record["worktree_tracked_changes"] == []
assert record["audit_directories_remaining_in_production_results"] == []
assert record["job_catalog.sqlite3_audit_rows"] == []
assert record["molecular_library.sqlite3_audit_rows"] == []
print(json.dumps(record, indent=2))

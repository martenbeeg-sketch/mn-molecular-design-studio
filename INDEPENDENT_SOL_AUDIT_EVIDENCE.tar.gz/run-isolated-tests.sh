#!/bin/bash
set -eu
audit_label="$1"
shift
audit_worktree=/home/user/.codex/worktrees/independent-sol-audit/mn-molecular-design-studio
audit_directory="/tmp/mds-independent-sol-20261111/$audit_label"
mkdir -p "$audit_directory"
exec bwrap --ro-bind / / --bind /tmp /tmp --bind "$audit_worktree" "$audit_worktree" \
  --dev /dev --unshare-net --tmpfs /run --tmpfs /mnt --die-with-parent -- \
  env MN_MOLECULAR_DESIGN_STUDIO_HOME="$audit_directory/studio" \
  MN_MOLECULAR_DESIGN_STUDIO_APP_HOME="$audit_directory/studio" \
  MN_MOLECULAR_DESIGN_STUDIO_RUN_DIR="$audit_directory/runs" \
  MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR="$audit_directory/reference" \
  MDS_CLUSTER_HOME="$audit_directory/cluster" \
  MN_MOLECULAR_DESIGN_STUDIO_AUTH_MODE=production \
  MN_MOLECULAR_DESIGN_STUDIO_SCHEDULER_MODE=local \
  MDS_GPU_TESTS=0 MDS_QC_DOCKER_TESTS=0 MDS_RFD4_DOCKER_TESTS=0 \
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$audit_worktree:$audit_worktree/tests" \
  /home/user/mambaforge/envs/mn-molecular-design-studio/bin/python -m pytest "$@"

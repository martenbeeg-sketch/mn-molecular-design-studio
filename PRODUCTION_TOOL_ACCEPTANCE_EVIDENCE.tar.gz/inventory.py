import argparse
import ast
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timezone
import importlib
import inspect
import json
import os
from pathlib import Path
import re
import socket
import subprocess

import yaml

parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--reference", type=Path, required=True)
options = parser.parse_args()
source = Path(__file__).resolve().parent / "source"
import mn_molecular_design_studio as studio
source = Path(studio.__file__).resolve().parent.parent
from mn_molecular_design_studio.pipeline_graph import NODE_CATALOG, STARTER_TEMPLATES, SUPPORTED_TEMPLATE_IDS
from mn_molecular_design_studio.engine.workflow_engine.services.workflow_automation import WORKFLOWS
from mn_molecular_design_studio.engine.workflow_engine.workflows.optimized_prediction import ENGINE_PROFILES
from mn_molecular_design_studio.quality_tools import TOOLS as QC_TOOLS
from mn_molecular_design_studio import mpnn_input


def command(arguments, timeout=20):
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=timeout)
    return {"exit_code": result.returncode, "stdout": result.stdout.strip(), "stderr": result.stderr.strip()}


references = {}
def reference(path):
    path = Path(path)
    path = path if path.is_absolute() else options.reference / path
    exists = path.exists()
    row = {"path": str(path), "available": exists, "kind": "file" if path.is_file() else "directory" if path.is_dir() else "missing",
        "size": path.stat().st_size if path.is_file() else None}
    references[str(path)] = row
    return row


manifests = {}
for path in (source / "mn_molecular_design_studio/engine/workflow_engine/manifests").glob("*.yaml"):
    value = yaml.safe_load(path.read_text())
    if isinstance(value, dict):
        manifests[path.stem] = {key: value.get(key) for key in ("tool", "image", "gpu", "description")}
ligand = json.loads((source / "mn_molecular_design_studio/engine/workflow_engine/vendor/ligand_runtime/mn_ligand/manifests/tools.json").read_text())["tools"]
for row in ligand:
    row["installed_references"] = [reference(value["path"]) for value in row.get("references", []) if value.get("required", True)]

images = {row.get("image") for row in [*manifests.values(), *ENGINE_PROFILES.values(), *QC_TOOLS.values(), *ligand] if row.get("image")}
module_images = {}
for path in (source / "mn_molecular_design_studio").rglob("*.py"):
    found = set()
    for node in ast.walk(ast.parse(path.read_text())):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and re.fullmatch(r"mn-[a-zA-Z0-9_./-]+:[a-zA-Z0-9_.-]+", node.value):
            found.add(node.value)
    if found:
        module_images[str(path.relative_to(source))] = sorted(found)
        images.update(found)

image_state = {}
for image in sorted(images):
    result = command(["docker", "image", "inspect", image])
    if result["exit_code"]:
        image_state[image] = {"available": False}
    else:
        value = json.loads(result["stdout"])[0]
        image_state[image] = {"available": True, "id": value["Id"], "repo_digests": value.get("RepoDigests", []),
            "architecture": value.get("Architecture"), "created": value.get("Created")}

workflows = []
for workflow, specification in WORKFLOWS.items():
    row = asdict(specification)
    try:
        module = importlib.import_module(specification.module)
        function = getattr(module, specification.function)
        row["callable"] = callable(function)
        signature = inspect.signature(function)
        row["required_arguments"] = [name for name, parameter in signature.parameters.items()
            if parameter.default is inspect.Parameter.empty and parameter.kind not in
            {inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD}]
    except Exception as error:
        row["callable"] = False
        row["import_error"] = type(error).__name__ + ": " + str(error)
    manifest = manifests.get(specification.tool)
    row["declared_manifest"] = manifest
    workflows.append(row)

mpnn = []
for model, specification in mpnn_input.MODELS.items():
    for noise in specification["noise"] or [None]:
        mpnn.append({"model": model, "noise": noise, **reference(mpnn_input.checkpoint(model, noise, root=options.reference))})
for path in ["boltz_models/boltz2_conf.ckpt", "boltz_models/boltz2_aff.ckpt", "boltz_models/ccd.pkl",
    "rfdiffusion_models/Complex_base_ckpt.pt", "alphafold_models/params_model_1_multimer_v3.npz",
    "alphafold_models/params_model_1_ptm.npz", "protenix/checkpoint/protenix-v2.pt",
    "protenix/common/components.cif.rdkit_mol.pkl",
    "rfd4-proteina/huggingface/hub/models--nvidia--RFD4-Proteina/snapshots/a06e2509c7033b010fc43614e9fd840303588502/model.safetensors"]:
    reference(path)
for tool in QC_TOOLS.values():
    for path in tool.get("references", []):
        reference(path)

result = {"captured_at": datetime.now(timezone.utc).isoformat(), "hostname": socket.gethostname(),
    "source": str(source), "revision": command(["git", "-C", str(source), "rev-parse", "HEAD"])["stdout"],
    "reference_root": str(options.reference), "images": image_state, "module_image_literals": module_images,
    "workflows": workflows, "nodes": [{"id": key, **{name: value.get(name) for name in
        ("label", "category", "workflow", "hidden")}} for key, value in NODE_CATALOG.items()],
    "starter_templates": STARTER_TEMPLATES, "supported_templates": sorted(SUPPORTED_TEMPLATE_IDS),
    "optimized_predictors": ENGINE_PROFILES, "quality_tools": QC_TOOLS, "ligand_tools": ligand,
    "mpnn_checkpoints": mpnn, "references": list(references.values()),
    "gpu_inventory": command(["nvidia-smi", "--query-gpu=index,name,uuid,driver_version,memory.total,memory.used,utilization.gpu", "--format=csv"]),
    "containers": command(["docker", "ps", "--format", "{{.ID}} {{.Image}} {{.Names}}"]),
    "production_services": command(["systemctl", "--user", "show", "studio-api.service", "studio-agent.service", "studio-ui.service",
        "-p", "Id", "-p", "MainPID", "-p", "ActiveState", "-p", "WorkingDirectory"]),
    "evidence_class": "inventory and import checks, not scientific execution"}
options.output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
options.output.write_text(json.dumps(result, indent=2, default=str) + "\n")
print(json.dumps({"host": result["hostname"], "workflows": len(workflows), "noncallable": [row["workflow_id"] for row in workflows if not row["callable"]],
    "nodes": len(NODE_CATALOG), "images_available": sum(row["available"] for row in image_state.values()), "images_known": len(image_state),
    "templates": len(SUPPORTED_TEMPLATE_IDS), "mpnn_checkpoints_present": sum(row["available"] for row in mpnn), "mpnn_checkpoints_known": len(mpnn)}))

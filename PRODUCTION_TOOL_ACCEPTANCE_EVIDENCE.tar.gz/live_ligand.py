import json
import math
import os
from pathlib import Path
import traceback

from mn_molecular_design_studio import ligand_compounds
from mn_molecular_design_studio.engine.workflow_engine.core.jobs import read_json
from mn_molecular_design_studio.engine.workflow_engine.core.candidates import read_candidates
from mn_molecular_design_studio.engine.workflow_engine.workflows import ligand_tools, quality

root = Path(os.environ["MDS_ACCEPTANCE_ROOT"]) / os.environ.get("MDS_LIGAND_SUBDIR", "ligand")
root.mkdir(mode=0o700, exist_ok=True)
source = Path(os.environ["MDS_ACCEPTANCE_SOURCE"])
target = source / "mn_molecular_design_studio/assets/vina/1iep.pdb"
original_target = target
example = json.loads((target.parent / "imatinib.json").read_text())[0]
compound_set = root / "compound-set.json"
ligand_compounds.write_compound_set(compound_set, name="Isolated public imatinib example",
    compounds=[example], owner_id="11111111111111111111111111111111", project_id="production-acceptance", created_at="2026-11-11")
coordinates = []
for line in target.read_text().splitlines():
    if line.startswith("HETATM") and line[17:20].strip() == "STI" and line[21] == "A":
        coordinates.append([float(line[start:start + 8]) for start in (30, 38, 46)])
assert coordinates
target = root / "1iep-chain-A-protein-only.pdb"
target.write_text("\n".join(line for line in original_target.read_text().splitlines()
    if line.startswith("ATOM") and line[21] == "A") + "\nTER\nEND\n")
center = [sum(values[index] for values in coordinates) / len(coordinates) for index in range(3)]
receipts = []


def record(name, operation):
    try:
        run = operation()
        result = read_json(run / "result.json")
        row = {"tool": name, "run_dir": str(run), "success": result.get("success"), "result": result}
    except Exception as error:
        run = None
        row = {"tool": name, "success": False, "error": type(error).__name__ + ": " + str(error), "traceback": traceback.format_exc()}
    receipts.append(row)
    (root / "receipt.json").write_text(json.dumps({"scope": "one public 1IEP/imatinib CPU example, not affinity validation", "tools": receipts}, indent=2, default=str) + "\n")
    print(json.dumps({key: row[key] for key in ("tool", "success", "error") if key in row}), flush=True)
    return run


docking = record("vina", lambda: ligand_tools.run_ligand_vina(target, compound_set,
    center_x=center[0], center_y=center[1], center_z=center[2], size_x=24.0, size_y=24.0, size_z=24.0,
    exhaustiveness=1, num_modes=1, seed=20261111, compound_limit=1, cpu_cores=2, use_scrub=False, import_to_database=False))
if docking and read_json(docking / "result.json").get("success"):
    for name, function in (("plip", quality.run_plip), ("pandamap", quality.run_pandamap), ("posebusters", quality.run_posebusters)):
        record(name, lambda function=function: function(docking, None, cpu_cores=2))

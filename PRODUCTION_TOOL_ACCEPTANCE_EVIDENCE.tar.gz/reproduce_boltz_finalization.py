import hashlib
import json
import os
from pathlib import Path
import shutil

from mn_molecular_design_studio.engine.workflow_engine.core.artifact_collection import validate_run_artifacts

base = Path("/tmp/mds-production-acceptance-20261111")
original = next((base / "gpu/artifacts").glob("*/test_real_boltz_sampling_and_recycling[[]1-1-True]/runs/*/*"))
copy = base / "boltz-finalization-diagnostic-copy"
assert not copy.exists()
shutil.copytree(original, copy, symlinks=True)
before = validate_run_artifacts(copy, result={})
assert before["status"] == "incomplete"
changed = []
for path in copy.rglob("*"):
    if not path.is_symlink():
        continue
    relative = path.relative_to(copy)
    target = os.readlink(path)
    if ".mn-predict-boltz2-inputs" not in relative.parts:
        continue
    assert target.startswith("/work/artifacts/raw/optimized_prediction/inputs/") and target.endswith(".yaml")
    canonical_relative = Path(target.removeprefix("/work/"))
    canonical = copy / canonical_relative
    assert canonical.is_file() and not canonical.is_symlink()
    expected = hashlib.sha256((original / canonical_relative).read_bytes()).hexdigest()
    assert hashlib.sha256(canonical.read_bytes()).hexdigest() == expected
    path.unlink()
    shutil.copyfile(canonical, path)
    changed.append({"alias": str(relative), "canonical": str(canonical_relative), "sha256": expected})
after = validate_run_artifacts(copy, result={})
assert changed and after["status"] == "complete", after
assert validate_run_artifacts(original)["status"] == "incomplete"
unchanged = 0
for path in original.rglob("*"):
    if path.is_file() and not path.is_symlink():
        assert hashlib.sha256(path.read_bytes()).digest() == hashlib.sha256((copy / path.relative_to(original)).read_bytes()).digest()
        unchanged += 1
assert json.loads((original / "result.json").read_text())["success"] is False
result = {"original_run": str(original), "original_job_still_failed": True,
    "diagnostic_copy_only": True, "application_code_changed": False, "production_modified": False,
    "only_input_alias_copies_added": changed, "original_regular_files_unchanged": unchanged,
    "validation_before": before, "validation_after": after,
    "scope": "isolates the finalization defect without new inference or repairing the original run"}
(base / "boltz-finalization-reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"original_still_failed": True, "diagnostic_alias_copies": len(changed),
    "original_regular_files_preserved": unchanged, "copy_validation_before": before["status"], "copy_validation_after": after["status"]}))

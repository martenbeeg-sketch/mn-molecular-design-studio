import copy
import json
import os
from pathlib import Path
import secrets
import shutil
from zipfile import ZipFile

from mn_molecular_design_studio import auth, workspace, pipeline_graph as graph, design_validation as comparison
from mn_molecular_design_studio.engine.workflow_engine.core.jobs import create_job, finish_job, read_json
from mn_molecular_design_studio.engine.workflow_engine.core.candidates import read_candidates, write_candidates
from mn_molecular_design_studio.engine.workflow_engine.core.artifacts import build_run_zip
from mn_molecular_design_studio.engine.workflow_engine.workflows.graph_pipeline import run_graph_pipeline
from mn_molecular_design_studio.output_vocabulary import metric_value

base = Path(os.environ["MDS_ACCEPTANCE_ROOT"]) / os.environ.get("MDS_GRAPH_SUBDIR", "live-graph")
base.mkdir(exist_ok=True, mode=0o700)
workspace.save_settings({"results_directory": os.environ["MN_MOLECULAR_DESIGN_STUDIO_RUN_DIR"],
    "reference_directory": os.environ["MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR"], "api_base_url": "http://127.0.0.1:9"})
instructor = auth.create_initial_admin("acceptance_instructor", "Isolated production acceptance", secrets.token_urlsafe(24))
project = workspace.create_project("Public-reference graph acceptance", owner_id=instructor["id"])
source = create_job("analysis", "experimental_reference_import", "experimental_reference", {}, {"not_generated": True})
structure = source.run_dir / "artifacts/reference/7eow.pdb"
structure.parent.mkdir(parents=True)
shutil.copyfile(Path(os.environ["MDS_ACCEPTANCE_SOURCE"]) / "mn_molecular_design_studio/assets/generators/protpardelle/motifs/nanobody/7eow_AB_atom.pdb", structure)
sequence = comparison.sequence(comparison.protein_chains(comparison.read_structure(structure))["B"])
rows = [{"candidate_id": "experimental-reference-" + str(index), "source_tool": "experimental_reference", "stage": "reference",
    "complex_pdb": str(structure), "target_pdb": str(structure), "binder_chains": ["B"], "target_chains": ["A"],
    "binder_sequence": sequence, "metrics": {}, "raw_metadata": {"reference_origin": "7EOW repository experimental structure; no generator or predictor was run"}}
    for index in range(2)]
write_candidates(source.run_dir, "experimental_reference", rows)
workspace.mark_studio_job({"job": {"run_dir": str(source.run_dir)}}, owner_id=instructor["id"], project_id=project["id"])
finish_job(source.run_dir, True, {"downstream_artifacts": {"candidates_jsonl": "artifacts/normalized_candidates/candidates.jsonl"}})
pipeline = graph.new_graph("blank")
kinds = ["project_design_source", "sequence_qc", "sequence_clustering", "results"]
pipeline["nodes"] = []
for index, kind in enumerate(kinds):
    specification = graph.NODE_CATALOG[kind]
    parameters = {field["name"]: copy.deepcopy(field["default"]) for field in specification["fields"]}
    if kind == "project_design_source":
        parameters.update(source_run_dir=str(source.run_dir), source_scope="complex_results",
            selected_candidate_ids=[row["candidate_id"] for row in rows])
    pipeline["nodes"].append({"id": kind, "type": "studio", "position": {"x": index * 300, "y": 100},
        "data": {"kind": kind, "label": specification["label"], "params": parameters}})
pipeline["edges"] = [{"id": "edge-" + str(index), "source": kinds[index], "target": kinds[index + 1],
    "sourceHandle": "out", "targetHandle": "in"} for index in range(len(kinds) - 1)]
pipeline = graph.clean_graph(pipeline)
graph.validate_graph(pipeline, require_inputs=True)
parent = run_graph_pipeline(pipeline, "Real CPU QC and cohort graph acceptance", instructor["id"], project["id"],
    reuse_completed=False, gpu_device="none")
result = read_json(parent / "result.json")
receipt = {"run_dir": str(parent), "source_run": str(source.run_dir), "success": result.get("success"),
    "result": result, "scope": "actual graph orchestration with fresh native CPU workers on experimental reference input"}
(base / "receipt.json").write_text(json.dumps(receipt, indent=2, default=str) + "\n")
assert result.get("success") is True, result
outputs = read_candidates(parent)
assert len(outputs) == 2
assert all(metric_value(row, "evidence/analysis/sequence_qc/qc_sequence_length") == len(sequence) for row in outputs)
assert len({row["metrics"]["diversity_cluster"] for row in outputs}) == 1
archive = parent / "acceptance-export.zip"
archive.write_bytes(build_run_zip(parent))
with ZipFile(archive) as bundle:
    assert "artifacts/normalized_candidates/candidates.jsonl" in bundle.namelist()
receipt.update(candidate_count=len(outputs), same_sequence_shared_cluster=True, result_export_verified=True)
(base / "receipt.json").write_text(json.dumps(receipt, indent=2, default=str) + "\n")
print(json.dumps({key: receipt[key] for key in ("run_dir", "success", "candidate_count", "same_sequence_shared_cluster", "result_export_verified")}))

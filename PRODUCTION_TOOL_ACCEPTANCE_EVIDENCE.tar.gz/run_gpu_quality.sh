#!/usr/bin/env bash
set -euo pipefail
base=/tmp/mds-production-acceptance-20261111
source=/home/user/.codex/worktrees/production-tool-acceptance/mn-molecular-design-studio
mkdir -p "$base/gpu-quality/app" "$base/gpu-quality/runs" "$base/gpu-quality/tmp" "$base/gpu-quality/home"
export MDS_ACCEPTANCE_ROOT="$base" MDS_ACCEPTANCE_SOURCE="$source"
export MDS_LIVE_CPU_SUBDIR=gpu-quality MDS_QC_TOOL_LIST=esm1v_score,esmif_score
export MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR=/mnt/db/reference_files
export DOCKER_HOST
DOCKER_HOST=$(/usr/bin/docker context inspect "$(/usr/bin/docker context show)" --format '{{.Endpoints.docker.Host}}')
exec /home/user/mambaforge/envs/mn-molecular-design-studio/bin/python "$base/leased_run.py" \
  --output "$base/gpu-quality-lease.json" --timeout 360 -- \
  bwrap --ro-bind / / --bind "$base" "$base" --dev-bind /dev /dev --unshare-net --die-with-parent -- \
  env PATH="$base/bin:$PATH" HOME="$base/gpu-quality/home" TMPDIR="$base/gpu-quality/tmp" \
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$source:/home/user/.local/lib/python3.11/site-packages" \
  MN_MOLECULAR_DESIGN_STUDIO_HOME="$base/gpu-quality/app" MN_MOLECULAR_DESIGN_STUDIO_APP_HOME="$base/gpu-quality/app" \
  MN_MOLECULAR_DESIGN_STUDIO_RUN_DIR="$base/gpu-quality/runs" MDS_CLUSTER_HOME="$base/gpu-quality/cluster" \
  MN_MOLECULAR_DESIGN_STUDIO_AUTH_MODE=production MN_MOLECULAR_DESIGN_STUDIO_SCHEDULER_MODE=local \
  HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  /home/user/mambaforge/envs/mn-molecular-design-studio/bin/python "$base/live_cpu_tools.py"

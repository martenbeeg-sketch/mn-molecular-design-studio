import argparse
import csv
import ctypes
import io
import json
from pathlib import Path
import subprocess

from mn_molecular_design_studio.cluster.gpu_runtime import _PROBE, _PROTENIX_KERNEL_PROBE, compatible

parser = argparse.ArgumentParser()
parser.add_argument("--inventory", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
options = parser.parse_args()
inventory = json.loads(options.inventory.read_text())
wanted = {value["image"] for value in inventory["optimized_predictors"].values()}
wanted.update(row["declared_manifest"]["image"] for row in inventory["workflows"]
    if row.get("declared_manifest") and row["declared_manifest"].get("gpu") and row["declared_manifest"].get("image"))
wanted.update(value["image"] for value in inventory["quality_tools"].values() if value.get("gpu"))
result = {}
for image in sorted(wanted):
    state = inventory["images"].get(image, {})
    if not state.get("available"):
        result[image] = {"available": False}
        continue
    probe = _PROBE + (_PROTENIX_KERNEL_PROBE if image.startswith("mn-protenix-opt:") else "") + "\nprint(json.dumps(inventory))"
    command = ["docker", "run", "--rm", "--pull=never", "--runtime=runc", "--network=none",
        "--cap-drop=ALL", "--security-opt=no-new-privileges", "--memory=2g", "--cpus=1", "--pids-limit=128",
        "--label", "mds.acceptance=cpu-runtime-profiles", "--env", "NVIDIA_VISIBLE_DEVICES=void", "--entrypoint", "/usr/bin/env", state["id"],
        "-u", "PROTENIX_OPT_MODE", "python", "-c", probe]
    try:
        operation = subprocess.run(command, capture_output=True, text=True, timeout=40)
        row = {"available": True, "image_id": state["id"], "exit_code": operation.returncode}
        if operation.returncode == 0:
            row["profile"] = json.loads(operation.stdout.strip().splitlines()[-1])
        else:
            row["error"] = operation.stderr[-1500:]
    except Exception as error:
        row = {"available": True, "image_id": state["id"], "error": type(error).__name__ + ": " + str(error)}
    result[image] = row
    options.output.write_text(json.dumps({"hostname": inventory["hostname"], "profiles": result}, indent=2) + "\n")

version = ctypes.c_int()
assert ctypes.CDLL("libcuda.so.1").cuDriverGetVersion(ctypes.byref(version)) == 0
listing = subprocess.check_output(["nvidia-smi", "--query-gpu=index,name,compute_cap", "--format=csv,noheader"], text=True)
hardware = [{"gpu_id": fields[0].strip(), "name": fields[1].strip(), "compute_capability": float(fields[2]),
    "driver_cuda_api": version.value} for fields in csv.reader(io.StringIO(listing))]
for image, row in result.items():
    profile = row.get("profile") or {}
    if profile.get("targets"):
        row["compatible_gpus"] = {gpu["gpu_id"]: compatible(gpu, {image: profile}) for gpu in hardware}
    elif row.get("available"):
        row["compatibility_status"] = "unknown; a missing CUDA inventory is not a successful engine check"
value = {"hostname": inventory["hostname"], "gpu_hardware": hardware, "profiles": result,
    "scope": "CPU-only imports and CUDA binary targets; no model inference or GPU allocation"}
options.output.write_text(json.dumps(value, indent=2) + "\n")
print(json.dumps({"host": inventory["hostname"], "images": len(result),
    "profiles_available": sum(bool(row.get("profile", {}).get("targets")) for row in result.values()),
    "incompatible": [image for image, row in result.items() if row.get("compatible_gpus") and not any(row["compatible_gpus"].values())],
    "unknown": [image for image, row in result.items() if row.get("compatibility_status")]}))

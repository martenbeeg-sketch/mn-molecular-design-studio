import json
from pathlib import Path
from zipfile import ZipFile

from mn_molecular_design_studio.engine.workflow_engine.core.candidates import read_candidates
from mn_molecular_design_studio.engine.workflow_engine.core.artifacts import build_run_zip
from mn_molecular_design_studio.output_vocabulary import metric_value

base = Path("/tmp/mds-production-acceptance-20261111/live-graph-final")
receipt = json.loads((base / "receipt.json").read_text())
assert receipt["success"] is True
parent = Path(receipt["run_dir"])
rows = read_candidates(parent)
source = read_candidates(Path(receipt["source_run"]))
assert len(rows) == len(source) == 2
expected = len(source[0]["binder_sequence"])
assert all(metric_value(row, "evidence/analysis/sequence_qc/qc_sequence_length") == expected for row in rows)
assert len({metric_value(row, "evidence/analysis/sequence_clustering/diversity_cluster") for row in rows}) == 1
assert sum(bool(row["metrics"]["diversity_representative"]) for row in rows) == 1
assert all(Path(row["complex_pdb"]).is_file() for row in rows)
archive = parent / "acceptance-export.zip"
archive.write_bytes(build_run_zip(parent))
with ZipFile(archive) as bundle:
    assert "artifacts/normalized_candidates/candidates.jsonl" in bundle.namelist()
    coordinates_in_zip = any(name.endswith((".pdb", ".cif", ".mmcif")) for name in bundle.namelist())
receipt.update(candidate_count=2, upstream_method_qualified_sequence_lengths=[expected, expected],
    same_sequence_shared_cluster=True, one_cohort_representative=True, result_export_verified=True,
    coordinates_accessible_in_workspace=True, coordinates_in_parent_zip=coordinates_in_zip,
    self_contained_pipeline_export_accepted=coordinates_in_zip,
    note="Method-qualified upstream measurements are retained. The parent run ZIP does not include the sibling child-run coordinates and is not a self-contained pipeline archive.")
(base / "verified-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({key: receipt[key] for key in ("success", "candidate_count", "upstream_method_qualified_sequence_lengths",
    "same_sequence_shared_cluster", "one_cohort_representative", "result_export_verified")}))

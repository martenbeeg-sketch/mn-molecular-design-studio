#!/usr/bin/env bash
set -euo pipefail
base=/tmp/mds-production-acceptance-20261111
source=/home/user/.codex/worktrees/production-tool-acceptance/mn-molecular-design-studio
phase=${MDS_ACCEPTANCE_PHASE:-gpu}
targets=("$@")
if [ ${#targets[@]} -eq 0 ]; then
  targets=(tests/test_prediction_configuration_gpu.py tests/test_scientific_gpu.py tests/test_two_stage_mpnn_gpu.py tests/test_vhh_gpu.py)
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export MDS_ACCEPTANCE_ROOT="$base" MDS_ACCEPTANCE_SOURCE="$source"
export MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR=/mnt/db/reference_files
export DOCKER_HOST
DOCKER_HOST=$(/usr/bin/docker context inspect "$(/usr/bin/docker context show)" --format '{{.Endpoints.docker.Host}}')
exec /home/user/mambaforge/envs/mn-molecular-design-studio/bin/python "$base/leased_run.py" \
  --output "$base/$phase-lease.json" --timeout 1800 -- \
  bwrap --ro-bind / / --bind "$base" "$base" --dev-bind /dev /dev --unshare-net --die-with-parent -- \
  env PATH="$base/bin:$PATH" HOME="$base/gpu/unix-home" TMPDIR="$base/gpu/tmp" XDG_CACHE_HOME="$base/gpu/cache" \
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$source:/home/user/.local/lib/python3.11/site-packages" \
  MN_MOLECULAR_DESIGN_STUDIO_HOME="$base/gpu/app" MN_MOLECULAR_DESIGN_STUDIO_APP_HOME="$base/gpu/app" \
  MN_MOLECULAR_DESIGN_STUDIO_RUN_DIR="$base/gpu/runs" MDS_CLUSTER_HOME="$base/gpu/cluster" \
  MN_MOLECULAR_DESIGN_STUDIO_CACHE_DIR="$base/gpu/cache/cofolding" \
  MN_MOLECULAR_DESIGN_STUDIO_AUTH_MODE=production MN_MOLECULAR_DESIGN_STUDIO_SCHEDULER_MODE=local \
  MN_COMPUTE_SCHEDULER_API_URL=http://127.0.0.1:9 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
  MDS_GPU_TESTS=1 MDS_TEST_GPU=0 MDS_GPU_ARTIFACTS="$base/gpu/artifacts" \
  /home/user/mambaforge/envs/mn-molecular-design-studio/bin/python -m pytest -v -s \
  "${targets[@]}" \
  -o cache_dir="$base/gpu/pytest-cache" --basetemp="$base/gpu/pytest-temp-$phase" --junitxml="$base/$phase-suite.xml"

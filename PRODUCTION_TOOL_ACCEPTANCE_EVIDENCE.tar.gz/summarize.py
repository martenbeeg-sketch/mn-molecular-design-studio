from collections import Counter
import csv
import json
from pathlib import Path
import xml.etree.ElementTree as ElementTree

root = Path("/tmp/mds-production-acceptance-20261111")
destination = Path("/home/user/.codex/worktrees/production-tool-acceptance/mn-molecular-design-studio")
inventories = [json.loads(path.read_text()) for path in sorted(root.glob("*inventory.json"))]
primary = next(value for value in inventories if value["hostname"] == "pc002975")


def suite(name):
    cases = list(ElementTree.parse(root / name).iter("testcase"))
    result = {"total": len(cases), "passed": 0, "failed": 0, "skipped": 0, "errors": 0, "cases": []}
    for case in cases:
        status = "errors" if case.find("error") is not None else "failed" if case.find("failure") is not None else "skipped" if case.find("skipped") is not None else "passed"
        result[status] += 1
        result["cases"].append({"name": case.attrib["name"], "class": case.attrib.get("classname"), "status": status})
    return result


scientific_runs = []
for case in sorted((root / "gpu/artifacts").glob("*/*")):
    for path in sorted((case / "runs").glob("*/*/metadata.json")):
        metadata = json.loads(path.read_text())
        outcome = json.loads((path.parent / "result.json").read_text())
        candidates_path = path.parent / "artifacts/normalized_candidates/candidates.jsonl"
        native_path = path.parent / "artifacts/raw/optimized_prediction/output/mn-batch-result.json"
        native = json.loads(native_path.read_text()) if native_path.exists() else {}
        row = {"case": case.name, "run_id": path.parent.name, "run_dir": str(path.parent),
            "tool": metadata.get("tool"), "status": metadata.get("status"), "success": outcome.get("success"),
            "error": outcome.get("error"), "artifact_validation": outcome.get("artifact_validation"),
            "candidate_count": len(candidates_path.read_text().splitlines()) if candidates_path.exists() else 0,
            "native_exit_code": native.get("execution", {}).get("return_code"),
            "native_output_count": sum(value.get("output_count", 0) for value in native.get("items", [])),
            "native_status": native.get("status")}
        scientific_runs.append(row)

quality = []
for name in ("live-cpu-current/receipt.json", "gpu-quality/receipt.json", "ligand-prepared/receipt.json"):
    for row in json.loads((root / name).read_text())["tools"]:
        if row["tool"] == "vina":
            continue
        quality.append({"tool": row["tool"], "success": row["success"], "run_dir": row["run_dir"],
            "metrics": row.get("result", {}).get("metrics"), "scientific_status": row.get("scientific_status", row.get("result", {}).get("scientific_status")),
            "item_errors": [value.get("qc_error", "") for value in row.get("metrics", [])]})
assert len(quality) == 12
live = {"analysis." + row["tool"]: ("native_smoke_pass" if row["success"] else "native_smoke_fail") for row in quality}
live.update({"ligand.docking.vina": "native_smoke_pass_prepared_reference",
    "refolding.af2_initial_guess": "two_native_conditioning_modes_pass",
    "refolding.optimized_prediction": "boltz2_native_success_finalization_failure; other_engines_unverified",
    "design.rfdiffusion_generate": "native_generation_and_mpnn_chain_pass",
    "design.rfd4_proteina": "native_generation_pass; downstream_boltz2_fails",
    "design.esmfold2_binder": "native_vhh_generation_pass; downstream_boltz2_fails",
    "sequence.mpnn": "protein_soluble_and_ab_native_variants_checked; other_variants_unverified"})

matrix = []
for row in primary["workflows"]:
    manifest = row.get("declared_manifest") or {}
    image = manifest.get("image") or primary["quality_tools"].get(row["tool"], {}).get("image")
    matrix.append({"family": "workflow", "id": row["workflow_id"], "label": row["description"],
        "workflow": row["workflow_id"], "callable": row["callable"], "image": image or "not uniquely resolved",
        "native_status": live.get(row["workflow_id"], "not_executed"),
        "api_ui_end_to_end": "not_retested_here", "image_is_exact_requirement": bool(image)})
for node in primary["nodes"]:
    matrix.append({"family": "canvas_node", "id": node["id"], "label": node["label"], "workflow": node.get("workflow") or "graph_internal",
        "callable": "registry_checked", "image": "see_workflow_and_variant", "native_status": "see_workflow; topology_only_otherwise",
        "api_ui_end_to_end": "not_retested_here", "image_is_exact_requirement": False})
for engine, profile in primary["optimized_predictors"].items():
    matrix.append({"family": "optimized_predictor", "id": engine, "label": engine,
        "workflow": "refolding.optimized_prediction", "callable": True, "image": profile["image"],
        "native_status": "native_success_finalization_failure" if engine == "boltz2" else "not_executed",
        "api_ui_end_to_end": "not_retested_here", "image_is_exact_requirement": True})
for tool in primary["ligand_tools"]:
    matrix.append({"family": "ligand_manifest_tool", "id": tool["tool_id"], "label": tool["name"], "workflow": "separate_worker_or_studio_adapter",
        "callable": "manifest_only", "image": tool["image"],
        "native_status": "checked_via_studio_adapter" if tool["tool_id"] in {"vina", "plip", "pandamap", "posebusters"} else "not_executed",
        "api_ui_end_to_end": "vendor_worker_not_certified", "image_is_exact_requirement": True})
for model in sorted({row["model"] for row in primary["mpnn_checkpoints"]}):
    matrix.append({"family": "mpnn_model", "id": model, "label": model, "workflow": "sequence.mpnn", "callable": True,
        "image": "mn-ligandmpnn:latest", "native_status": "default_native_variant_pass" if model in {"protein_mpnn", "soluble_mpnn", "ab_mpnn"} else "not_executed",
        "api_ui_end_to_end": "not_retested_here", "image_is_exact_requirement": True})
for row in matrix:
    for inventory in inventories:
        observed = inventory["images"].get(row["image"], {})
        row[inventory["hostname"] + "_image_available"] = observed.get("available", "not_resolved")
        row[inventory["hostname"] + "_image_id"] = observed.get("id", "")

with (destination / "PRODUCTION_TOOL_MATRIX.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(matrix[0]))
    writer.writeheader()
    writer.writerows(matrix)
summary = {"baseline": primary["revision"], "decision": "NO-GO for unrestricted all-tools production rollout",
    "full_suite": suite("full-suite.xml"), "native_adapter_fixtures": suite("native-fixtures.xml"),
    "gpu_suite": suite("gpu-suite.xml"), "esm_vhh_followup": suite("esm-vhh-suite.xml"),
    "quality_tools": quality, "quality_tools_passed": sum(row["success"] for row in quality),
    "quality_tools_total": len(quality), "scientific_runs": scientific_runs,
    "graph": json.loads((root / "live-graph-final/verified-receipt.json").read_text()),
    "fleet": [{"host": value["hostname"], "revision": value["revision"], "workflows": len(value["workflows"]),
        "image_tags_observed": len(value["images"]), "image_tags_available": sum(row["available"] for row in value["images"].values()),
        "missing_image_tags": [key for key, row in value["images"].items() if not row["available"]],
        "gpu_inventory": value["gpu_inventory"], "production_services": value["production_services"]} for value in inventories],
    "matrix_rows": len(matrix), "matrix_families": dict(Counter(row["family"] for row in matrix)),
    "coverage_note": "Rows include aliases and variants, not 273 distinct tools. Callable/image/topology checks are not live scientific passes."}
(root / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
print(json.dumps({"matrix_rows": len(matrix), "matrix_families": summary["matrix_families"],
    "gpu_passed": summary["gpu_suite"]["passed"], "gpu_failed": summary["gpu_suite"]["failed"],
    "qc_passed": summary["quality_tools_passed"], "qc_total": len(quality),
    "native_boltz_jobs": sum(row["native_exit_code"] == 0 for row in scientific_runs),
    "native_boltz_outputs": sum(row["native_output_count"] for row in scientific_runs)}))

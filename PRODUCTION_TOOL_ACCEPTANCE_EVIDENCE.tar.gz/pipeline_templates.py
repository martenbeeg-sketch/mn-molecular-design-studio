import json
from pathlib import Path
import traceback

from mn_molecular_design_studio.pipeline_graph import NODE_CATALOG, STARTER_TEMPLATES, SUPPORTED_TEMPLATE_IDS, new_graph, validate_graph
from mn_molecular_design_studio.engine.workflow_engine.services.workflow_automation import WORKFLOWS

rows = []
for name in sorted(SUPPORTED_TEMPLATE_IDS):
    row = {"template": name, "visible_labels": [label for label, value in STARTER_TEMPLATES.items() if value == name]}
    try:
        graph = new_graph(name)
        row["node_count"] = len(graph["nodes"])
        row["nodes"] = [node["data"]["kind"] for node in graph["nodes"]]
        row["unregistered_routes"] = [NODE_CATALOG[kind].get("workflow") for kind in row["nodes"]
            if NODE_CATALOG[kind].get("workflow") and NODE_CATALOG[kind]["workflow"] not in WORKFLOWS]
        validated = validate_graph(graph, require_inputs=False)
        row["topology_valid"] = True
    except Exception as error:
        row["topology_valid"] = False
        row["error"] = type(error).__name__ + ": " + str(error)
    rows.append(row)
result = {"scope": "factory and graph topology, not scientific execution or completed user inputs", "templates": rows}
Path("/tmp/mds-production-acceptance-20261111/pipeline-templates.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"templates": len(rows), "topology_valid": sum(row["topology_valid"] for row in rows),
    "not_valid": [{key: row[key] for key in ("template", "error") if key in row} for row in rows if not row["topology_valid"]]}))

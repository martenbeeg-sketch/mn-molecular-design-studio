from pathlib import Path
import json
import re
from xml.etree import ElementTree as ET

root = Path('/tmp/mds-production-ready-20261112')
collection = (root / 'collected-final.txt').read_text()
expected = {line for line in collection.splitlines() if line.startswith('tests/') and '::' in line}
collection_skips = {name[:-3].replace('/', '.') for name in re.findall(r'SKIPPED \[\d+\] (tests/[^:]+\.py):\d+', collection)}
modules = {name.split('::')[0][:-3].replace('/', '.'): name.split('::')[0] for name in expected}


def identifier(case):
    classname = case.get('classname', '')
    for module in sorted(modules, key=len, reverse=True):
        if classname == module or classname.startswith(module + '.'):
            classes = classname[len(module):].strip('.').replace('.', '::')
            return modules[module] + ('::' + classes if classes else '') + '::' + case.get('name', '')
    return classname + '::' + case.get('name', '')


seen, skipped_modules, shards = set(), set(), []
for folder in ('core-final', 'modes', 'auth-final', 'tls-final'):
    cases = list(ET.parse(root / folder / 'results.xml').iter('testcase'))
    case_ids = {identifier(case) for case in cases if case.get('classname')}
    assert not seen.intersection(case_ids)
    seen.update(case_ids)
    skipped_modules.update(case.get('name') for case in cases if not case.get('classname') and case.find('skipped') is not None)
    failures = [case.get('name') for case in cases if case.find('failure') is not None or case.find('error') is not None]
    skipped = sum(case.find('skipped') is not None for case in cases)
    assert not failures
    shards.append({'shard': folder, 'passed': len(cases) - skipped, 'skipped': skipped, 'case_records': len(cases)})
assert seen == expected
assert skipped_modules == collection_skips
result = {'application_commit': '87cb209e3884844076434df601e80a6152bf3c18',
          'application_runtime_fingerprint': '62bf990569d7d8ab64bab9ade6ddd194d02b0214192826e977c0f7831db3d487',
          'source_archive_sha256': 'db8a705786b7e8bab5f41cfe79a1e51b1c66b203c1c7d8a29d04e73bf566353f',
          'expected_cases': len(expected), 'collection_module_skips': len(collection_skips),
          'complete_disjoint_case_coverage': True, 'shards': shards,
          'passed': sum(row['passed'] for row in shards), 'skipped': sum(row['skipped'] for row in shards),
          'science_native_validation': 'Earlier corrected scientific application 86804ff; see PRODUCTION_TOOL_FIXES.md. No new all-tools inference certification.',
          'student_production_access': 'Instructor only; student-access preference has not yet been answered.'}
(root / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

from pathlib import Path
import http.client
import json
import ssl
import subprocess

context = ssl.create_default_context(cafile='/home/user/Downloads/MDS-Research-LAN-CA.crt')
observed = {}
for name, path, source, headers in [('health', '/_stcore/health', None, {}), ('api', '/api/v1/health', None, {}),
        ('outside', '/_stcore/health', ('127.0.0.1', 0), {}),
        ('forged_forwarded', '/_stcore/health', ('127.0.0.1', 0), {'X-Forwarded-For': '172.18.24.171'})]:
    connection = http.client.HTTPSConnection('172.18.24.170', 18503, timeout=10, context=context, source_address=source)
    connection.request('GET', path, headers=headers)
    observed[name] = connection.getresponse().status
    connection.close()
connection = http.client.HTTPConnection('172.18.24.170', 18503, timeout=10)
connection.request('GET', '/')
observed['plaintext_http'] = connection.getresponse().status
connection.close()
assert observed == {'health': 200, 'api': 404, 'outside': 403, 'forged_forwarded': 403, 'plaintext_http': 400}
try:
    connection = http.client.HTTPSConnection('172.18.24.170', 18503, timeout=10)
    connection.request('GET', '/')
    raise AssertionError('Research CA unexpectedly installed into default client trust')
except ssl.SSLCertVerificationError:
    observed['untrusted_client_rejected'] = True
observed['tls_service'] = subprocess.check_output(['systemctl', '--user', 'show', 'mds-research-tls.service', '-p', 'Result', '-p', 'ExecMainStatus'], text=True).strip()
observed['timer'] = subprocess.check_output(['systemctl', '--user', 'is-enabled', 'mds-research-tls.timer'], text=True).strip()
Path('/tmp/mds-production-ready-20261112/gateway-checks.json').write_text(json.dumps(observed, indent=2) + '\n')
print(json.dumps(observed))

"""Private, explicit-root release recovery capture; never starts or stops services."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import socket
import sqlite3
import stat
import subprocess
import time


def run(arguments):
    return subprocess.run(arguments, check=True, text=True, capture_output=True).stdout


def entries(root):
    for directory, directories, files in os.walk(root, followlinks=False):
        directories.sort()
        files.sort()
        for name in [*directories, *files]:
            path = Path(directory) / name
            yield path, path.lstat()


def sqlite_files(root):
    result = []
    for path, info in entries(root):
        if stat.S_ISREG(info.st_mode):
            with path.open('rb') as handle:
                if handle.read(16) == b'SQLite format 3\x00':
                    result.append(path.relative_to(root))
    return result


def fingerprint(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def copy_root(source, destination, base, exceptions=(), sqlite_paths=()):
    destination.mkdir(mode=0o700, exist_ok=True)
    options = ['rsync', '-aHXS', '--numeric-ids', '--stats', '--exclude=*-wal', '--exclude=*-shm', '--exclude=*-journal']
    for relative in [*exceptions, *sqlite_paths]:
        options.append('--exclude=/' + str(relative))
    if base is not None:
        options.append('--link-dest=' + str(base))
    return run([*options, str(source) + '/', str(destination) + '/'])


def snapshot_sqlite(source, destination):
    destination.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    temporary = destination.with_name(destination.name + '.consistent-new')
    if temporary.exists():
        raise RuntimeError('Refusing existing SQLite staging path')
    with sqlite3.connect(source.as_uri() + '?mode=ro', uri=True, timeout=20) as reader:
        with sqlite3.connect(temporary) as writer:
            started = time.monotonic()
            def progress(status, remaining, total):
                if time.monotonic() - started > 300:
                    raise TimeoutError('SQLite recovery snapshot exceeded five minutes')
            reader.backup(writer, pages=1024, progress=progress)
            integrity = writer.execute('PRAGMA integrity_check').fetchall()
            if integrity != [('ok',)]:
                raise RuntimeError('SQLite recovery integrity check failed: ' + str(source))
            foreign_keys = writer.execute('PRAGMA foreign_key_check').fetchall()
            if foreign_keys != reader.execute('PRAGMA foreign_key_check').fetchall():
                raise RuntimeError('Foreign-key baseline changed during recovery capture')
            tables = [row[0] for row in writer.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
            counts = {table: writer.execute('SELECT count(*) FROM "' + table.replace('"', '""') + '"').fetchone()[0] for table in tables}
    temporary.chmod(0o600)
    temporary.replace(destination)
    for suffix in ('-wal', '-shm', '-journal'):
        Path(str(destination) + suffix).unlink(missing_ok=True)
    return {'integrity': 'ok', 'foreign_key_baseline_count': len(foreign_keys), 'counts': counts,
            'sha256': fingerprint(destination), 'bytes': destination.stat().st_size}


def verify_inventory(source, destination, exceptions, sqlite_paths):
    counts = {'regular': 0, 'symlink': 0, 'directory': 0, 'logical_bytes': 0}
    exclusions = set(map(str, exceptions))
    databases = set(map(str, sqlite_paths))
    for path, info in entries(source):
        relative = path.relative_to(source)
        if str(relative) in exclusions or str(relative).endswith(('-wal', '-shm', '-journal')):
            continue
        copied = destination / relative
        other = copied.lstat()
        if stat.S_IFMT(info.st_mode) != stat.S_IFMT(other.st_mode):
            raise RuntimeError('Recovery entry type mismatch: ' + str(relative))
        if stat.S_ISLNK(info.st_mode):
            if os.readlink(path) != os.readlink(copied):
                raise RuntimeError('Recovery link mismatch: ' + str(relative))
            counts['symlink'] += 1
        elif stat.S_ISREG(info.st_mode):
            if str(relative) not in databases and (info.st_size, info.st_mtime_ns) != (other.st_size, other.st_mtime_ns):
                raise RuntimeError('Recovery file metadata mismatch: ' + str(relative))
            counts['regular'] += 1
            counts['logical_bytes'] += info.st_size
        elif stat.S_ISDIR(info.st_mode):
            counts['directory'] += 1
        else:
            raise RuntimeError('Unsupported recovery entry: ' + str(relative))
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'finalize'])
    parser.add_argument('--app', type=Path, required=True)
    parser.add_argument('--workdir', type=Path, required=True)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    options = parser.parse_args()
    os.umask(0o077)
    app, workdir, base, destination = [value.resolve(strict=True) if value != options.destination else value.absolute()
        for value in (options.app, options.workdir, options.base, options.destination)]
    if destination.exists() and not (destination / 'capture-roots.json').exists():
        raise RuntimeError('Refusing unrecognized existing recovery destination')
    destination.mkdir(parents=True, mode=0o700, exist_ok=True)
    roots = {'app': str(app), 'workdir': str(workdir), 'base': str(base), 'host': socket.gethostname()}
    marker = destination / 'capture-roots.json'
    if marker.exists() and json.loads(marker.read_text()) != roots:
        raise RuntimeError('Recovery roots changed')
    marker.write_text(json.dumps(roots, indent=2) + '\n')
    exception_file = Path.home() / 'mn-mds-recovery/20261108T222428Z-recovery1/metadata/results-exceptions.jsonl'
    exceptions = []
    if exception_file.exists():
        exceptions = [row['path'] for row in map(json.loads, exception_file.read_text().splitlines())]
    if not exceptions:
        for name in ('exclusion-paths-tar.txt',):
            path = exception_file.parent / name
            if path.exists():
                exceptions = [line.removeprefix('./') for line in path.read_text().splitlines() if line]
    if options.mode == 'finalize':
        for unit in ('studio-api.service', 'studio-agent.service', 'studio-ui.service'):
            status = subprocess.run(['systemctl', '--user', 'is-active', unit], capture_output=True, text=True).stdout.strip()
            if status not in {'inactive', 'failed', 'unknown'}:
                raise RuntimeError('Studio writer still active: ' + unit)
        for process in Path('/proc').iterdir():
            if not process.name.isdigit() or int(process.name) == os.getpid():
                continue
            try:
                environment = process.joinpath('environ').read_bytes().split(b'\0')
            except OSError:
                continue
            if any(value in environment for value in [b'MN_MOLECULAR_DESIGN_STUDIO_APP_HOME=' + os.fsencode(app),
                    b'MN_MOLECULAR_DESIGN_STUDIO_HOME=' + os.fsencode(app)]):
                raise RuntimeError('Process still has the research application home: ' + process.name)
    databases = sqlite_files(app)
    (destination / 'app-rsync.log').write_text(copy_root(app, destination / 'app', base / 'app-home', sqlite_paths=databases))
    (destination / 'workdir-rsync.log').write_text(copy_root(workdir, destination / 'workdir', base / 'results', exceptions))
    if options.mode == 'prepare':
        print(json.dumps({'host': socket.gethostname(), 'prepared': True, 'destination': str(destination)}))
        return
    receipts = {}
    for relative in databases:
        receipts[str(relative)] = snapshot_sqlite(app / relative, destination / 'app' / relative)
    scheduler = Path.home() / '.local/state/mn-compute-scheduler'
    scheduler_sql = sqlite_files(scheduler)
    (destination / 'scheduler-rsync.log').write_text(copy_root(scheduler, destination / 'scheduler', None, sqlite_paths=scheduler_sql))
    for relative in scheduler_sql:
        receipts['scheduler/' + str(relative)] = snapshot_sqlite(scheduler / relative, destination / 'scheduler' / relative)
    shutil.copytree(Path.home() / '.config/systemd/user', destination / 'systemd-user', symlinks=True)
    summary = {'host': socket.gethostname(), 'quiet_studio_state': True, 'shared_scheduler_stopped': False,
               'sqlite': receipts, 'app_inventory': verify_inventory(app, destination / 'app', [], databases),
               'workdir_inventory': verify_inventory(workdir, destination / 'workdir', exceptions, []),
               'exceptions_preserved_in_place': exceptions,
               'copy_method': 'rsync -aHXS; unchanged size/mtime/attributes hard-linked from prior isolated restore, never from live data',
               'limitation': 'Metadata comparison of all non-SQLite entries; not a fresh cryptographic reread of every historical trajectory byte.'}
    (destination / 'recovery-receipt.json').write_text(json.dumps(summary, indent=2) + '\n')
    shutil.copy2(__file__, destination / 'capture_recovery.py')
    print(json.dumps({'host': socket.gethostname(), 'captured': True, 'sqlite_databases': len(receipts),
                      'app_inventory': summary['app_inventory'], 'workdir_inventory': summary['workdir_inventory']}))


if __name__ == '__main__':
    main()

from pathlib import Path
import json
import sqlite3
import sys

home = Path.home()
expected = json.loads((home / 'tmp/mds-production-ready-20261112/restore.json').read_text())
app = home / '.local/share/mn-molecular-design-studio'
result = []
with sqlite3.connect((app / 'database/molecular_library.sqlite3').as_uri() + '?mode=ro', uri=True) as connection:
    for entry in expected['restored_structure_checks']:
        if entry['state'] != 'historically-unavailable':
            continue
        path = connection.execute('SELECT path FROM molecule_structures WHERE id=?', (entry['structure_id'],)).fetchone()[0]
        assert path.startswith('cluster-library://'), 'An actual missing local sample needs investigation'
        result.append({'structure_id': entry['structure_id'], 'reference': path, 'state': 'explicit-remote-reference-not-a-local-file'})
Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'remote_references': len(result), 'missing_local_samples': 0}))

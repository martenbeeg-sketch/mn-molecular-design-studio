"""Runs only with a private restored app home and read-only recovered workdir."""
from pathlib import Path
import hashlib
import json
import os
import sqlite3
import sys

app = Path(os.environ['MN_MOLECULAR_DESIGN_STUDIO_APP_HOME'])
database_path = app / 'database/molecular_library.sqlite3'
tables = ('molecules', 'molecule_groups', 'molecule_members', 'molecule_sources',
          'molecule_structures', 'molecule_observations', 'complex_review_annotations')


def baseline():
    result = {}
    with sqlite3.connect(database_path.as_uri() + '?mode=ro', uri=True) as connection:
        for table in tables:
            digest = hashlib.sha256()
            count = 0
            for row in connection.execute('SELECT * FROM ' + table + ' ORDER BY rowid'):
                digest.update(json.dumps(row, sort_keys=True, default=str).encode() + b'\n')
                count += 1
            result[table] = {'rows': count, 'sha256': digest.hexdigest()}
    return result


before = baseline()
from mn_molecular_design_studio import auth, workspace
from mn_molecular_design_studio.molecular_database import MolecularDatabase
from mn_molecular_design_studio.complex_analysis_design_review import design_review_query
from mn_molecular_design_studio.cluster import config

node_before = config.identity()
assert auth.user_count() == 0
instructor = auth.create_initial_admin('recovery_instructor', 'Recovery rehearsal only',
    'private-disposable-recovery-password', preserve_development_owner=True)
assert instructor['id'] == auth.development_user()['id']
assert instructor['must_change_password']
assert auth.authenticate('recovery_instructor', 'private-disposable-recovery-password')[0]['id'] == instructor['id']
student = auth.create_user('recovery_student', 'Recovery rehearsal only', 'private-disposable-student-password', actor=instructor)
database = MolecularDatabase()
with database.connection() as connection:
    groups = [row[0] for row in connection.execute("SELECT id FROM molecule_groups WHERE origin LIKE '%20261021-184403-b0c849c0%' OR origin LIKE '%20261021-190947-7ea80083%' OR origin LIKE '%20261022-224027-4c669b6e%' ORDER BY id")]
    structures = connection.execute('SELECT id,path,context FROM molecule_structures ORDER BY id LIMIT 50').fetchall()
    evaluations = connection.execute('SELECT count(*) FROM molecule_evaluations').fetchone()[0]
assert groups
page = design_review_query(database, instructor, groups, limit=3)
assert page['scoped_total'] > 0
for group in groups:
    try:
        database._authorize_group_ids_for_query(student, [group])
    except PermissionError:
        continue
    raise AssertionError('Student gained access to private research during bootstrap')
retained = []
for row in structures:
    path = Path(row['path'])
    if not path.is_absolute():
        path = database.root / path
    context = json.loads(row['context'])
    if not path.is_file():
        retained.append({'structure_id': row['id'], 'state': 'historically-unavailable'})
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    expected = context.get('portable_sha256') or context.get('content_sha256') or context.get('sha256')
    if expected:
        assert digest == expected, 'Recovered canonical structure digest changed'
    retained.append({'structure_id': row['id'], 'state': 'readable', 'sha256': digest})
assert config.identity() == node_before
after = baseline()
assert before == after, 'Ordinary startup/review/bootstrap changed canonical scientific records'
result = {'passed': True, 'scientific_tables_unchanged': after, 'evaluations': evaluations,
          'protected_campaign_groups': len(groups), 'review_scope_models': page['scoped_total'],
          'restored_structure_checks': retained, 'legacy_owner_preserved': True,
          'student_private_research_denied': True, 'node_identity_preserved': node_before,
          'loaded_source': str(Path(sys.modules['mn_molecular_design_studio.auth'].__file__).resolve())}
Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('passed', 'evaluations', 'protected_campaign_groups', 'review_scope_models', 'legacy_owner_preserved', 'student_private_research_denied')}))

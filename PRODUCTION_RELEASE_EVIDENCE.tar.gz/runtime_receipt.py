from pathlib import Path
import hashlib
import json
import os
import socket
import sqlite3
import subprocess
import sys
import urllib.request

source = Path.home() / 'programs/deployments/mn-molecular-design-studio/prod-87cb209e3884/source'
expected = '62bf990569d7d8ab64bab9ade6ddd194d02b0214192826e977c0f7831db3d487'
units = {}
for name in ('studio-api.service', 'studio-agent.service', 'studio-ui.service'):
    metadata = dict(line.split('=', 1) for line in subprocess.check_output(['systemctl', '--user', 'show', name,
        '-p', 'MainPID', '-p', 'ActiveState', '-p', 'WorkingDirectory'], text=True).splitlines())
    assert metadata['WorkingDirectory'] == str(source)
    process = int(metadata['MainPID'])
    if process:
        process_root = Path('/proc') / str(process)
        environment = dict(item.split('=', 1) for item in process_root.joinpath('environ').read_bytes().decode().split('\0') if '=' in item)
        assert environment['MN_MOLECULAR_DESIGN_STUDIO_AUTH_MODE'] == 'production'
        assert environment['PYTHONPATH'] == str(source)
        assert process_root.joinpath('cwd').resolve() == source
        metadata.update(authentication='production', imported_source_path=environment['PYTHONPATH'],
                        python_executable=str(process_root.joinpath('exe').resolve()))
    elif name != 'studio-ui.service':
        raise AssertionError('A required API/agent process is inactive')
    units[name] = metadata
app = Path.home() / '.local/share/mn-molecular-design-studio'
node = app.joinpath('cluster/node-id').read_text().strip()
with sqlite3.connect((app / 'cluster/coordinator.sqlite3').as_uri() + '?mode=ro', uri=True) as connection:
    snapshot = json.loads(connection.execute('SELECT snapshot FROM nodes WHERE id=?', (node,)).fetchone()[0])
    pending = connection.execute("SELECT count(*) FROM commands WHERE status NOT IN ('completed','cancelled','failed')").fetchone()[0]
assert snapshot['code_revision'] == expected
assert pending == 0
with urllib.request.urlopen('http://127.0.0.1:8766/api/v1/health', timeout=10) as response:
    assert json.load(response)['status'] == 'ok'
result = {'host': socket.gethostname(), 'application_revision': '87cb209e3884844076434df601e80a6152bf3c18',
          'reported_runtime_code_fingerprint': snapshot['code_revision'], 'source': str(source), 'units': units,
          'node_id': node, 'api_healthy': True, 'pending_cluster_commands': pending,
          'accept_jobs': snapshot.get('accept_jobs'), 'scheduler_online': snapshot.get('scheduler_online')}
Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'host': result['host'], 'runtime_verified': True, 'authentication': 'production', 'pending_commands': pending}))

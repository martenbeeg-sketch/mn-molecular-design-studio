from pathlib import Path
import json
import urllib.request
import urllib.error

credentials = json.loads((Path.home() / '.config/mn-molecular-design-studio/production-credentials.json').read_text())['accounts'][0]
results = []
for port in (8766, 18762, 18763):
    base = 'http://127.0.0.1:' + str(port)
    try:
        urllib.request.urlopen(base + '/api/v1/workflows', timeout=10)
        raise AssertionError('Anonymous access was allowed')
    except urllib.error.HTTPError as error:
        assert error.code == 401
    body = json.dumps({'username': credentials['username'], 'password': credentials['temporary_password']}).encode()
    with urllib.request.urlopen(urllib.request.Request(base + '/api/v1/auth/login', data=body,
            headers={'Content-Type': 'application/json'}), timeout=10) as response:
        authenticated = json.load(response)
    token = authenticated['access_token']
    assert token != 'development-mode'
    headers = {'Authorization': 'Bearer ' + token}
    with urllib.request.urlopen(urllib.request.Request(base + '/api/v1/auth/me', headers=headers), timeout=10) as response:
        user = json.load(response)
    assert user['id'] == '00000000000000000000000000000001'
    assert user['must_change_password'] and not user['development_mode']
    try:
        urllib.request.urlopen(urllib.request.Request(base + '/api/v1/workflows', headers=headers), timeout=10)
        raise AssertionError('Temporary-password session could submit work before reset')
    except urllib.error.HTTPError as error:
        assert error.code == 403
    with urllib.request.urlopen(urllib.request.Request(base + '/api/v1/auth/logout', data=b'', headers=headers), timeout=10) as response:
        assert json.load(response)['status'] == 'signed_out'
    results.append({'port': port, 'anonymous_denied': True, 'real_signin': True, 'legacy_owner_preserved': True,
                    'first_password_change_enforced': True, 'test_session_revoked': True})
output = Path('/tmp/mds-production-ready-20261112/live-signin.json')
output.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results))

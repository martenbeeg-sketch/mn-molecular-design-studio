from pathlib import Path
import hashlib
import json
import os
import sqlite3
import sys

expected = json.loads(Path(sys.argv[1]).read_text())
app = Path.home() / '.local/share/mn-molecular-design-studio'
database_path = app / 'database/molecular_library.sqlite3'
observed = {}
with sqlite3.connect(database_path.as_uri() + '?mode=ro', uri=True) as connection:
    for table in expected['scientific_tables_unchanged']:
        digest = hashlib.sha256()
        count = 0
        for row in connection.execute('SELECT * FROM ' + table + ' ORDER BY rowid'):
            digest.update(json.dumps(row, sort_keys=True, default=str).encode() + b'\n')
            count += 1
        observed[table] = {'rows': count, 'sha256': digest.hexdigest()}
    for structure in expected['restored_structure_checks']:
        path = connection.execute('SELECT path FROM molecule_structures WHERE id=?', (structure['structure_id'],)).fetchone()[0]
        path = Path(path)
        if not path.is_absolute():
            path = database_path.parent / path
        if structure['state'] == 'readable':
            assert hashlib.sha256(path.read_bytes()).hexdigest() == structure['sha256']
        else:
            assert not path.is_file()
assert observed == expected['scientific_tables_unchanged'], 'Live canonical science differs from pre-upgrade recovery baseline'
assert (app / 'cluster/node-id').read_text().strip() == expected['node_identity_preserved']
with sqlite3.connect((app / 'database/user_access.sqlite3').as_uri() + '?mode=ro', uri=True) as connection:
    accounts = connection.execute('SELECT id,username,role,must_change_password FROM users').fetchall()
assert accounts == [('00000000000000000000000000000001', 'research_instructor', 'admin', 1)]
result = {'passed': True, 'canonical_science_unchanged': observed,
          'structure_sample_unchanged': len(expected['restored_structure_checks']),
          'node_identity_preserved': True, 'accounts': len(accounts)}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': True, 'canonical_tables_unchanged': len(observed), 'structure_sample_unchanged': result['structure_sample_unchanged'], 'accounts': len(accounts)}))

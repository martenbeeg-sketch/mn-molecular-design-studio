from pathlib import Path
import importlib.util
import json
import os
import shutil
import sqlite3
import sys

os.umask(0o077)
root = Path(sys.argv[1])
destination = root / 'postcutover-identity-config'
destination.mkdir(mode=0o700)
spec = importlib.util.spec_from_file_location('capture_recovery', Path(__file__).with_name('capture_recovery.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
app = Path.home() / '.local/share/mn-molecular-design-studio'
receipts = {}
for relative in ('database/user_access.sqlite3', 'cluster/replication.sqlite3'):
    receipts[relative] = module.snapshot_sqlite(app / relative, destination / relative)
with sqlite3.connect(destination / 'database/user_access.sqlite3') as connection:
    connection.row_factory = sqlite3.Row
    user = dict(connection.execute('SELECT * FROM users WHERE id=?', ('00000000000000000000000000000001',)).fetchone())
with sqlite3.connect(destination / 'cluster/replication.sqlite3') as connection:
    record = json.loads(connection.execute('SELECT value FROM records WHERE key=?', ('user:' + user['id'],)).fetchone()[0])
assert user == record, 'Identity snapshot account/replica mismatch; do not use this unverified copy'
shutil.copytree(Path.home() / '.config/systemd/user', destination / 'systemd-user', symlinks=True)
private_credentials = Path.home() / '.config/mn-molecular-design-studio/production-credentials.json'
if private_credentials.exists():
    shutil.copy2(private_credentials, destination / 'production-credentials.private.json')
    shutil.copytree(Path.home() / 'programs/deployments/mn-molecular-design-studio/prod-87cb209e3884/lan-gateway',
                    destination / 'research-lan-gateway', symlinks=True)
result = {'paired_identity_verified': True, 'method': 'Read-only-source online SQLite backups; account payload equals its replica event',
          'application_commit': '87cb209e3884844076434df601e80a6152bf3c18', 'sqlite': receipts,
          'secrets_private_not_for_evidence_archive': True,
          'scope': 'Post-cutover identity/configuration supplement to the earlier full quiet-point snapshot, not an ongoing backup service'}
(destination / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'paired_identity_verified': True, 'postcutover_backup': str(destination)}))

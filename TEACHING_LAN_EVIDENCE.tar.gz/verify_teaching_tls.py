import asyncio
import hashlib
import http.client
import json
from pathlib import Path
import socket
import ssl

from tornado.httpclient import HTTPClientError, HTTPRequest
from tornado.websocket import websocket_connect

base = Path("/home/user/programs/deployments/mn-molecular-design-studio/teaching-pilot-current").resolve()
certificate = base / "lan-gateway/tls/teaching-ca.crt"
trusted = ssl.create_default_context(cafile=str(certificate))
host = "pc002975.marionegri.it"
root = "https://" + host + ":18502"

for context, hostname, expected_error in [(ssl.create_default_context(), host, ssl.SSLCertVerificationError),
                                          (trusted, "wrong-name.invalid", ssl.SSLError)]:
    with socket.create_connection(("172.18.24.170", 18502), timeout=10) as connection:
        try:
            with context.wrap_socket(connection, server_hostname=hostname):
                raise AssertionError("An untrusted or mismatched TLS identity was accepted")
        except expected_error:
            pass

connection = http.client.HTTPSConnection(host, 18502, timeout=10, context=trusted,
    source_address=("127.0.0.1", 0))
connection.request("GET", "/_stcore/health", headers={"X-Forwarded-For": "172.18.24.192"})
response = connection.getresponse()
assert response.status == 403
connection.close()
connection = http.client.HTTPConnection("172.18.24.170", 18502, timeout=10)
connection.request("GET", "/")
response = connection.getresponse()
assert response.status == 400
connection.close()


async def reject_cross_origin():
    try:
        connection = await websocket_connect(HTTPRequest(root.replace("https:", "wss:") + "/_stcore/stream",
            headers={"Origin": "https://outside.invalid"}, ssl_options=trusted, connect_timeout=10),
            subprotocols=["streamlit"])
    except HTTPClientError as error:
        assert error.code == 403
    else:
        connection.close()
        raise AssertionError("An unrelated cross-origin WebSocket was accepted")


asyncio.run(reject_cross_origin())
fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert(certificate.read_text())).hexdigest()
receipt = {"tls_ca_certificate_sha256": fingerprint,
    "untrusted_certificate_rejected": True, "unknown_sni_hostname_rejected": True,
    "outside_subnet_and_spoofed_forwarding_header_denied": 403,
    "plaintext_lan_http_rejected": 400, "unrelated_websocket_origin_denied": 403,
    "host_trust_store_modified": False, "production_modified": False}
print(json.dumps(receipt, indent=2))

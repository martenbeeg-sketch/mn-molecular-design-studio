import argparse
import asyncio
import concurrent.futures
import json
import socket
import ssl
import urllib.error
import urllib.request

from streamlit.proto.BackMsg_pb2 import BackMsg
from streamlit.proto.ForwardMsg_pb2 import ForwardMsg
from tornado.httpclient import HTTPRequest
from tornado.websocket import websocket_connect

parser = argparse.ArgumentParser()
parser.add_argument("--ca", required=True)
options = parser.parse_args()
context = ssl.create_default_context(cafile=options.ca)
root = "https://pc002975.marionegri.it:18502"
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context))


def request(path, *, ip=False):
    address = "https://172.18.24.170:18502" if ip else root
    try:
        with opener.open(address + path, timeout=20) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as error:
        return error.code, error.read()


assert request("/_stcore/health") == (200, b"ok")
assert request("/_stcore/health", ip=True) == (200, b"ok")
code, html = request("/")
assert code == 200 and b"streamlit" in html.lower()
assert request("/api/v1/health")[0] == 404
for host in ("pc002975.marionegri.it", "172.18.24.170"):
    with socket.socket() as connection:
        connection.settimeout(4)
        assert connection.connect_ex((host, 18766)) != 0

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    assert list(pool.map(lambda index: request("/_stcore/health"), range(4))) == [(200, b"ok")] * 4


async def browser_session():
    connection = await websocket_connect(HTTPRequest(root.replace("https:", "wss:") + "/_stcore/stream",
        headers={"Origin": root}, ssl_options=context, connect_timeout=15, request_timeout=30), subprotocols=["streamlit"])
    try:
        assert connection.selected_subprotocol == "streamlit"
        message = BackMsg()
        message.rerun_script.query_string = ""
        await connection.write_message(message.SerializeToString(), binary=True)
        session_id = None
        sign_in = False
        for attempt in range(100):
            raw = await asyncio.wait_for(connection.read_message(), timeout=25)
            assert raw is not None, "Streamlit closed the teaching session"
            incoming = ForwardMsg()
            incoming.ParseFromString(raw)
            if incoming.WhichOneof("type") == "new_session":
                session_id = incoming.new_session.initialize.session_id
            if "Sign in to Molecular Design Studio" in str(incoming):
                sign_in = True
            if session_id and sign_in:
                await asyncio.sleep(1)
                return session_id
        raise AssertionError("The sign-in page did not render over the TLS WebSocket")
    finally:
        connection.close()


async def concurrent_browsers():
    identities = await asyncio.gather(*(browser_session() for index in range(4)))
    assert len(set(identities)) == 4
    return len(identities)


count = asyncio.run(concurrent_browsers())
receipt = {"client": socket.gethostname(), "url": root,
    "hostname_and_ip_certificate_verified": True, "ui_and_health_reachable": True,
    "api_route_not_exposed": True, "api_port_not_reachable_over_lan": True,
    "four_concurrent_health_requests": True, "independent_streamlit_sessions": count,
    "four_signin_pages_rendered_over_verified_tls_websockets": True,
    "scope": "network and sign-in rendering, not authenticated browser journeys or GPU capacity"}
print(json.dumps(receipt, indent=2))

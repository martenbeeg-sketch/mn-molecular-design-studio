import hashlib
import json
from pathlib import Path
import re
from xml.etree import ElementTree as ET

base = Path('/tmp/mds-production-fixes-20261112')
live = Path('/tmp/mds-production-acceptance-20261111')
collection_path = base / 'final-collected.txt'
expected = {line for line in collection_path.read_text().splitlines() if line.startswith('tests/') and '::' in line} if collection_path.exists() else set()
collection_skips = {name[:-3].replace('/', '.') for name in re.findall(r'SKIPPED \[\d+\] (tests/[^:]+\.py):\d+', collection_path.read_text())} if collection_path.exists() else set()
modules = {name.split('::')[0][:-3].replace('/', '.'): name.split('::')[0] for name in expected}


def case_id(case):
    classname = case.get('classname', '')
    for module in sorted(modules, key=len, reverse=True):
        if classname == module or classname.startswith(module + '.'):
            classes = classname[len(module):].strip('.').replace('.', '::')
            return modules[module] + ('::' + classes if classes else '') + '::' + case.get('name', '')
    return classname + '::' + case.get('name', '')


def read(path):
    return json.loads(path.read_text()) if path.exists() else None


def junit(path, scope, complete=True, expected_ids=None, expected_collection_skips=None):
    if not path.exists():
        return {'scope': scope, 'status': 'pending', 'complete': False}
    cases = list(ET.parse(path).iter('testcase'))
    if expected_ids is not None:
        regular = [case for case in cases if case.get('classname')]
        skipped_modules = {case.get('name') for case in cases if not case.get('classname') and
                           case.find('skipped') is not None and case.find('skipped').get('message') == 'collection skipped'}
        complete = (complete and bool(expected_ids) and len(regular) == len(expected_ids) and {case_id(case) for case in regular} == expected_ids and
                    skipped_modules == (expected_collection_skips or set()))
    failures = [case.get('name') for case in cases if case.find('failure') is not None or case.find('error') is not None]
    skips = sum(case.find('skipped') is not None for case in cases)
    return {'scope': scope, 'complete': complete, 'executed_or_skipped': len(cases),
        'passed': len(cases) - len(failures) - skips if complete else None, 'skipped': skips, 'failures': failures,
        'seconds_sum': round(sum(float(case.get('time', '0')) for case in cases), 2)}


receipts = {
    'final_application_commit': '86804ff29f50d9846ba285d8d5b7f502c6d6dbdd',
    'principal_correction_commit': 'b333f3a2b36f5083d81ed53b001300e391efe320',
    'source_archive_sha256': '8db889f998e93cbe906e56713374f92cd50a10da9a7284bcf66b31940d185741',
    'regressions': [
        junit(base / 'shard-core/results.xml', 'final default CPU suite excluding workflow modes',
              expected_ids={name for name in expected if not name.startswith('tests/test_workflow_modes.py::')},
              expected_collection_skips=collection_skips),
        junit(base / 'shard-modes/results.xml', 'final workflow modes isolated CPU shard',
              expected_ids={name for name in expected if name.startswith('tests/test_workflow_modes.py::')}),
        junit(base / 'full-committed/results.xml', 'interrupted unsharded default CPU attempt; not a completed suite', False),
        junit(base / 'full-final/results.xml', 'earlier extended CPU sweep; manually interrupted during OpenMM', False),
        junit(base / 'native-fixture-corrected/results.xml', 'installed image-side adapter fixtures; controlled model calls'),
        junit(base / 'export-final-security/results.xml', 'final targeted review/inspection/export/quality contracts'),
        junit(base / 'export/results.xml', 'controller/export/UI sweep on principal correction'),
        junit(base / 'pc004032.marionegri.it-cpu-final-junit.xml', 'PC004032 final source isolated CPU slice'),
        junit(base / 'pc004033.marionegri.it-cpu-final-junit.xml', 'PC004033 final source isolated CPU slice'),
    ],
    'genie_image_equivalence': read(base / 'genie-image-equivalence.json'),
    'genie_native_5090': read(base / 'remote-native/genie-native-writable/receipt.json'),
    'genie_application_primary': read(live / 'genie-app-fixed/receipt.json'),
    'cpu_graph_export': None,
    'qc': [],
}
completed_shards = receipts['regressions'][:2]
receipts['combined_default_cpu'] = {'expected_test_cases': len(expected),
    'collection_module_skips': len(collection_skips),
    'complete': all(row.get('complete') and not row.get('failures') for row in completed_shards),
    'passed': sum(row.get('passed') or 0 for row in completed_shards),
    'skipped': sum(row.get('skipped') or 0 for row in completed_shards),
    'scope': 'disjoint test-file shards; not a successful monolithic run; no duplicated cases counted'}
for name in ('cpu-quality-final-20261112', 'gpu-quality-fixed'):
    receipt = read(live / name / 'receipt.json')
    if receipt:
        for tool in receipt['tools']:
            receipts['qc'].append({key: tool.get(key) for key in ('tool', 'success', 'scientific_status', 'required_metrics_present', 'candidate_count', 'run_dir')})
graph = read(live / 'live-graph-final-86804ff/receipt.json')
if graph:
    receipts['cpu_graph_export'] = {key: graph.get(key) for key in ('run_dir', 'success', 'candidate_count',
        'same_sequence_shared_cluster', 'result_export_verified', 'self_contained_final_candidate_export')}
outcomes = {}
for phase in ('gpu-fixed-20261112', 'gpu-tail-fixed-20261112'):
    path = live / (phase + '.log')
    if path.exists():
        for test, status in re.findall(r'(tests/\S+::\S+) (PASSED|FAILED|SKIPPED)', path.read_text()):
            outcomes[test] = status
receipts['gpu_unique_test_outcomes'] = outcomes
receipts['gpu_outcome_counts'] = {status: list(outcomes.values()).count(status) for status in ('PASSED', 'FAILED', 'SKIPPED')}
receipts['diagnostic_leases'] = {name: read(live / (name + '-lease.json')) for name in
    ('gpu-fixed-20261112', 'gpu-tail-fixed-20261112', 'gpu-quality-fixed', 'genie-app-fixed')}
checkpoint_hashes = {}
for path in base.glob('genie-reference-*.sha256'):
    checkpoint_hashes[path.name] = [line.split()[0] for line in path.read_text().splitlines()]
receipts['genie_checkpoint_hashes'] = checkpoint_hashes
(base / 'summary.json').write_text(json.dumps(receipts, indent=2) + '\n')
print(json.dumps({'regressions': receipts['regressions'], 'gpu_counts': receipts['gpu_outcome_counts'],
    'qc': [{key: row[key] for key in ('tool', 'success', 'scientific_status', 'required_metrics_present')} for row in receipts['qc']],
    'genie_primary': receipts['genie_application_primary'], 'graph': receipts['cpu_graph_export']}, indent=2))

import json
import math
import os
from pathlib import Path

from Bio.PDB import PDBParser
from mn_molecular_design_studio import workspace
from mn_molecular_design_studio.engine.workflow_engine.core.candidates import read_candidates
from mn_molecular_design_studio.engine.workflow_engine.core.jobs import read_json
from mn_molecular_design_studio.engine.workflow_engine.workflows.generators import run_genie3_generation

base = Path(os.environ['MDS_ACCEPTANCE_ROOT']) / 'genie-app-fixed'
base.mkdir(exist_ok=True)
workspace.save_settings({'results_directory': os.environ['MN_MOLECULAR_DESIGN_STUDIO_RUN_DIR'],
    'reference_directory': os.environ['MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR'], 'api_base_url': 'http://127.0.0.1:9'})
run = run_genie3_generation(task='unconditional', binder_length='40', num_designs=1, seed=20261112,
                           direction_scale=0.8, gpu_device='0', cpu_cores=4)
result = read_json(run / 'result.json')
rows = read_candidates(run)
assert result['success'] and len(rows) == 1, (run, result)
candidate = rows[0]
assert candidate['stage'] == 'generation.backbone'
path = Path(candidate['complex_pdb'])
structure = PDBParser(QUIET=True).get_structure('native', path)
ca = [atom for atom in structure.get_atoms() if atom.name == 'CA']
assert len(ca) == 40
assert all(math.isfinite(float(value)) for atom in structure.get_atoms() for value in atom.coord)
receipt = {'run_dir': str(run), 'success': result['success'], 'scientific_status': result.get('scientific_status'),
    'candidate_count': len(rows), 'stage': candidate['stage'], 'ca_count': len(ca),
    'scope': 'fresh native unconditional Genie3 through actual application worker and strict finalization, not all modes',
    'artifact_validation': result.get('artifact_validation')}
(base / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))

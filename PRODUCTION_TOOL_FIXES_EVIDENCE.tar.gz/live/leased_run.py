import argparse
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import threading
import time
import uuid

from mn_compute_scheduler import SchedulerClient

parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--timeout", type=int, default=1800)
parser.add_argument("command", nargs=argparse.REMAINDER)
options = parser.parse_args()
command = options.command[1:] if options.command[0] == "--" else options.command
client = SchedulerClient(timeout=8)
app = "mn-studio-production-acceptance"
worker = "production-check-" + uuid.uuid4().hex
workflow = "guarded.scientific.integration"
client.register_worker(app_id=app, worker_id=worker, workflows=[workflow], pid=os.getpid(), hostname=socket.gethostname(),
    labels={"purpose": "isolated release acceptance; not research jobs"})
submitted = client.submit_job(app_id=app, workflow=workflow, run_id=worker, run_dir=str(options.output.parent),
    name="Bounded offline scientific release acceptance", payload={},
    resource_request={"gpu": True, "gpu_ids": [0], "gpu_count": 1, "min_vram_gb": 20,
        "cpu_threads": 8, "ram_gb": 64, "scratch_gb": 20}, priority=0, max_attempts=1,
    idempotency_key=worker)
job = None
for attempt in range(15):
    job = client.claim_job(app_id=app, worker_id=worker)
    if job:
        break
    time.sleep(2)
if not job:
    client.cancel_job(submitted["job_id"])
    raise RuntimeError("GPU admission unavailable; cancelled only this diagnostic request")
stopped = threading.Event()
lost = threading.Event()
process = None


def heartbeat():
    while not stopped.wait(10):
        try:
            client.heartbeat_worker(app_id=app, worker_id=worker, pid=os.getpid())
            client.heartbeat_job(job["job_id"], worker_id=worker, lease_token=job["lease_token"], pid=os.getpid())
        except Exception:
            lost.set()
            if process is not None and process.poll() is None:
                process.terminate()
            return


thread = threading.Thread(target=heartbeat, daemon=True)
thread.start()
started = time.time()
error = ""
returncode = -1
environment = {**os.environ, "MDS_ACCEPTANCE_LABEL": worker}
try:
    process = subprocess.Popen(command, env=environment, start_new_session=True)
    try:
        returncode = process.wait(timeout=options.timeout)
    except subprocess.TimeoutExpired:
        error = "Bounded diagnostic timeout"
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=20)
except Exception as exception:
    error = type(exception).__name__ + ": " + str(exception)
finally:
    containers = subprocess.check_output(["/usr/bin/docker", "ps", "-q", "--filter", "label=mds.acceptance=" + worker], text=True).split()
    if containers:
        subprocess.run(["/usr/bin/docker", "stop", "--timeout", "15", *containers], check=False, capture_output=True)
    stopped.set()
    thread.join(timeout=10)
    success = returncode == 0 and not error and not lost.is_set()
    client.finish_job(job["job_id"], worker_id=worker, lease_token=job["lease_token"], success=success,
        result={"exit_code": returncode, "scope": "isolated acceptance only"}, error=error or ("Tests failed" if returncode else ""))
    options.output.write_text(json.dumps({"scheduler_job_id": job["job_id"], "diagnostic_app_id": app,
        "resource_request": job["resource_request"], "exit_code": returncode, "elapsed_seconds": time.time() - started,
        "error": error, "lease_heartbeat_lost": lost.is_set(), "research_jobs_modified": False,
        "test_containers_stopped_at_exit": len(containers)}, indent=2) + "\n")
raise SystemExit(returncode if returncode in range(256) else 1)

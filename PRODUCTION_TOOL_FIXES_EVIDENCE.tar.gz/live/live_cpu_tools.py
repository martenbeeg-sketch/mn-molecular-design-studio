import json
import math
import os
from pathlib import Path
import shutil
import traceback

from rdkit import Chem
from mn_molecular_design_studio import design_validation as comparison, ligand_compounds
from mn_molecular_design_studio.engine.workflow_engine.core.candidates import read_candidates, write_candidates
from mn_molecular_design_studio.engine.workflow_engine.core.jobs import read_json
from mn_molecular_design_studio.engine.workflow_engine.workflows import quality, ligand_tools
from mn_molecular_design_studio.quality_tools import TOOLS

base = Path(os.environ["MDS_ACCEPTANCE_ROOT"]) / os.environ.get("MDS_LIVE_CPU_SUBDIR", "live-cpu")
base.mkdir(mode=0o700, exist_ok=True)
source_root = Path(os.environ["MDS_ACCEPTANCE_SOURCE"])
source = base / "reference-protein"
source.mkdir(exist_ok=True)
structure = source_root / "mn_molecular_design_studio/assets/generators/protpardelle/motifs/nanobody/7eow_AB_atom.pdb"
copied = source / "experimental-reference.pdb"
shutil.copyfile(structure, copied)
chains = comparison.protein_chains(comparison.read_structure(copied))
sequence = comparison.sequence(chains["B"])
rows = [{"candidate_id": "reference-" + str(index), "source_tool": "experimental-reference", "stage": "reference",
    "complex_pdb": str(copied), "target_pdb": str(copied), "binder_chains": ["B"], "target_chains": ["A"],
    "binder_sequence": sequence, "metrics": {}, "raw_metadata": {"reference_origin": "repository 7EOW experimental fixture, not a generated design"}}
    for index in range(2)]
write_candidates(source, "experimental-reference", rows)
receipts = []


def record(tool, operation):
    try:
        run = operation()
        result = read_json(run / "result.json")
        candidates = read_candidates(run)
        expected = TOOLS.get(tool, {}).get("metrics", [])
        complete = len(candidates) == 2 and all(all(row.get("metrics", {}).get(key) is not None and
            (not isinstance(row["metrics"][key], (int, float)) or math.isfinite(row["metrics"][key])) for key in expected)
            for row in candidates)
        row = {"tool": tool, "run_dir": str(run), "success": result.get("success"),
            "scientific_status": result.get("scientific_status"), "required_metrics_present": complete,
            "candidate_count": len(candidates), "metrics": [candidate.get("metrics", {}) for candidate in candidates],
            "result": result}
    except Exception as error:
        row = {"tool": tool, "success": False, "error": type(error).__name__ + ": " + str(error), "traceback": traceback.format_exc()}
    receipts.append(row)
    (base / "receipt.json").write_text(json.dumps({"scope": "real offline CPU workers; isolated state and public fixture only", "tools": receipts}, indent=2, default=str) + "\n")
    print(json.dumps({key: row[key] for key in ("tool", "success", "scientific_status", "required_metrics_present", "error") if key in row}), flush=True)


selected_tools = os.environ.get("MDS_QC_TOOL_LIST", "sequence_qc,proteinsol,biotite_interface,sequence_clustering,interface_clustering,foldseek,pep_patch").split(",")
for tool in selected_tools:
    record(tool, lambda tool=tool: quality.run_quality(source, source / "artifacts/normalized_candidates/candidates.jsonl",
        tool=tool, settings={"ph": 7.4, "similarity_threshold": 0.5, "coverage": 0.8, "contact_distance": 5.0}, cpu_cores=2,
        gpu_device="0" if TOOLS[tool].get("gpu") else None))

#!/usr/bin/env bash
set -euo pipefail
base=/tmp/mds-production-acceptance-20261111
source=/home/user/programs/deployments/mn-molecular-design-studio/tools-86804ff29f50/source
state=$base/genie-app-fixed
mkdir -p "$state"/{home,tmp,app,runs}
export MDS_ACCEPTANCE_ROOT="$base" MDS_ACCEPTANCE_SOURCE="$source"
export MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR=/mnt/db/reference_files
export DOCKER_HOST
DOCKER_HOST=$(/usr/bin/docker context inspect "$(/usr/bin/docker context show)" --format '{{.Endpoints.docker.Host}}')
exec /home/user/mambaforge/envs/mn-molecular-design-studio/bin/python "$base/leased_run.py" \
  --output "$base/genie-app-fixed-lease.json" --timeout 900 -- \
  bwrap --ro-bind / / --bind "$base" "$base" --dev-bind /dev /dev --unshare-net --die-with-parent -- \
  env PATH="$base/bin:$PATH" HOME="$state/home" TMPDIR="$state/tmp" \
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$source:/home/user/.local/lib/python3.11/site-packages" \
  MN_MOLECULAR_DESIGN_STUDIO_HOME="$state/app" MN_MOLECULAR_DESIGN_STUDIO_APP_HOME="$state/app" \
  MN_MOLECULAR_DESIGN_STUDIO_RUN_DIR="$state/runs" MDS_CLUSTER_HOME="$state/cluster" \
  MN_MOLECULAR_DESIGN_STUDIO_AUTH_MODE=production MN_MOLECULAR_DESIGN_STUDIO_SCHEDULER_MODE=local \
  MN_COMPUTE_SCHEDULER_API_URL=http://127.0.0.1:9 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
  /home/user/mambaforge/envs/mn-molecular-design-studio/bin/python "$base/live_genie_app_fixed_20261112.py"

#!/usr/bin/python3
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

real = "/usr/bin/docker"
arguments = sys.argv[1:]
root = Path(os.environ["MDS_ACCEPTANCE_ROOT"]).resolve()
reference = Path(os.environ["MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR"]).resolve()
source = Path(os.environ["MDS_ACCEPTANCE_SOURCE"]).resolve()
label = os.environ["MDS_ACCEPTANCE_LABEL"]


def within(path, parent):
    return path == parent or parent in path.parents


def mount(value, modern):
    if modern:
        parts = value.split(",")
        settings = dict(part.split("=", 1) for part in parts if "=" in part)
        if settings.get("type", "bind") != "bind":
            raise RuntimeError("Only named private bind mounts are supported in this test")
        host = settings.get("src", settings.get("source", ""))
        destination = settings.get("dst", settings.get("destination", settings.get("target", "")))
    else:
        parts = value.split(":")
        if len(parts) not in {2, 3}:
            raise RuntimeError("A test volume requires an explicit host path")
        host, destination = parts[:2]
    if not Path(host).is_absolute() and re.fullmatch(r"mn-molecular-design-studio_biohub-esm-[a-z-]+cache", host):
        private_cache = root / "container-caches" / host
        private_cache.mkdir(parents=True, exist_ok=True, mode=0o700)
        host = str(private_cache)
        return host + ":" + destination + ":rw" if not modern else "type=bind,src=" + host + ",dst=" + destination
    path = Path(host).resolve(strict=True)
    if not any(within(path, parent) for parent in (root, reference, source)):
        raise RuntimeError("Refusing a bind outside the test, source and reference roots: " + host)
    if path.is_socket() or destination == "/var/run/docker.sock":
        raise RuntimeError("No Docker socket may be mounted into a scientific container")
    writable = within(path, root)
    if modern:
        parts = [part for part in parts if part not in {"rw", "readonly", "ro"} and not part.startswith("readonly=")]
        return ",".join(parts + ([] if writable else ["readonly"]))
    return host + ":" + destination + (":rw" if writable else ":ro")


if arguments and arguments[0] == "run":
    values = {"--name", "--cpus", "--memory", "--shm-size", "--gpus", "--mount", "--volume", "-v", "--env", "-e",
        "--workdir", "-w", "--user", "-u", "--entrypoint", "--runtime", "--ipc", "--network", "--net", "--label",
        "--tmpfs", "--security-opt", "--cap-drop", "--pids-limit", "--ulimit", "--hostname", "--pull"}
    flags = {"--rm", "--init", "-i", "--interactive", "-t", "--tty", "-d", "--detach", "--read-only"}
    effective = []
    gpu = False
    index = 1
    while index < len(arguments) and arguments[index].startswith("-"):
        item = arguments[index]
        option, separator, value = item.partition("=")
        if option in flags and not separator:
            effective.append(item)
            index += 1
            continue
        if option not in values:
            raise RuntimeError("Unreviewed Docker option: " + option)
        if not separator:
            index += 1
            value = arguments[index]
        if option == "--gpus":
            if value.strip('"') != "device=0":
                raise RuntimeError("Only the explicitly leased GPU 0 can be used")
            gpu = True
        if option in {"--mount", "--volume", "-v"}:
            value = mount(value, option == "--mount")
        if option in {"--network", "--net"} and value != "none":
            raise RuntimeError("Scientific test containers must stay offline")
        if option in {"--network", "--net"}:
            index += 1
            continue
        if option == "--ipc" and value == "host":
            raise RuntimeError("Host IPC is not part of this test")
        if option == "--pull" and value != "never":
            raise RuntimeError("Image downloads are not authorized by these tests")
        effective.extend([option, value])
        index += 1
    image = arguments[index]
    identity = subprocess.check_output([real, "image", "inspect", "--format", "{{.Id}}", image], text=True).strip()
    extra = ["--pull=never", "--network=none", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--memory=48g",
        "--pids-limit=1024", "--label", "mds.acceptance=" + label,
        "--env", "HF_HUB_OFFLINE=1", "--env", "TRANSFORMERS_OFFLINE=1"]
    if not gpu:
        extra.extend(["--runtime=runc", "--env", "NVIDIA_VISIBLE_DEVICES=void"])
    arguments = ["run", *extra, *effective, identity, *arguments[index + 1:]]
    receipt = {"at": time.time(), "requested_image": image, "image_id": identity, "gpu": gpu, "command": arguments}
    descriptor = os.open(root / "docker-commands.jsonl", os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    os.write(descriptor, (json.dumps(receipt) + "\n").encode())
    os.close(descriptor)
elif not arguments or arguments[0] not in {"image", "info", "version", "inspect", "ps"}:
    raise RuntimeError("Only diagnostic Docker launches and read-only inspection are allowed")
os.execv(real, [real, *arguments])

import hashlib
import json
import os
from pathlib import Path
import subprocess

base = Path('/home/compute/tmp/mds-production-fixes-20261112')
image = 'sha256:7549829b69548c7b45ecb3c251879f1595fe75fdb4ecc83dca42958c495fc1df'
output = base / 'genie-native-writable'
output.mkdir(parents=True, exist_ok=True)
(output / 'logs').mkdir(exist_ok=True)
(output / 'home').mkdir(exist_ok=True)
(output / 'lightning_logs').mkdir(exist_ok=True)
configuration = output / 'experiment.yaml'
configuration.write_text('''experiment:
  name: isolated_release_check
  seed: 20261112
paths:
  rootdir: /work/output
runtime:
  num_devices: 1
generation:
  compile: false
  dataset:
    n_sample: 1
    source: unconditional
    min_length: 40
    max_length: 40
    length_step: 1
  sampler:
    sampler:
      direction_scale: 0.8
''')
flags = ['docker', 'run', '--rm', '--gpus', 'device=0', '--network=none', '--pull=never', '--cap-drop=ALL',
         '--security-opt=no-new-privileges', '--memory=24g', '--pids-limit=512', '--cpus=4', '--shm-size=8g',
         '--label', 'mds.acceptance=' + __import__('os').environ['MDS_ACCEPTANCE_LABEL'],
         '--mount', f'type=bind,src={output},dst=/work',
         '--user', f'{os.getuid()}:{os.getgid()}', '--env', 'HOME=/work/home',
         '--mount', f'type=bind,src={output / "logs"},dst=/opt/genie3/logs',
         '--mount', f'type=bind,src={output / "lightning_logs"},dst=/opt/genie3/lightning_logs',
         '--mount', 'type=bind,src=/data/reference_files/genie3/pretrained,dst=/opt/genie3/pretrained,readonly',
         '--env', 'HF_HUB_OFFLINE=1', '--env', 'TRANSFORMERS_OFFLINE=1', '--env', 'OMP_NUM_THREADS=4',
         '--hostname', 'localhost', '--env', 'MASTER_ADDR=127.0.0.1', '--env', 'GLOO_SOCKET_IFNAME=lo',
         '--env', 'NCCL_SOCKET_IFNAME=lo', '--env', 'NCCL_SOCKET_FAMILY=AF_INET']
probe = subprocess.run([*flags, '--entrypoint', 'python', image, '-c',
    'import torch,json; value=(torch.arange(8,device="cuda")**2).sum(); torch.cuda.synchronize(); '
    'print(json.dumps({"cuda":torch.version.cuda,"targets":torch._C._cuda_getArchFlags(),"value":value.item()}))'],
    capture_output=True, text=True, timeout=120)
(output / 'cuda-probe.log').write_text(probe.stdout + probe.stderr)
assert probe.returncode == 0, probe.stderr
with (output / 'native.log').open('w') as log:
    native = subprocess.run([*flags, '--entrypoint', '/bin/bash', '-w', '/opt/genie3', image,
        '-c', 'exec "$@"', 'native-check', 'genie3', 'generate', '-c', '/work/experiment.yaml',
        '--num-devices', '1', '--verbose'], stdout=log, stderr=subprocess.STDOUT, timeout=600)
structures = sorted((output / 'output').glob('**/pdbs/*.pdb'))
receipt = {'image_id': image, 'cuda_probe_exit_code': probe.returncode, 'native_exit_code': native.returncode,
    'scope': 'one fresh unconditional 40-residue native sample on PC004033; not all Genie modes or scientific accuracy',
    'structures': [{'path': str(path.relative_to(output)), 'bytes': path.stat().st_size,
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in structures]}
(output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert native.returncode == 0 and len(structures) == 1, receipt
assert any(line.startswith('ATOM') for line in structures[0].read_text().splitlines())
print(json.dumps(receipt))

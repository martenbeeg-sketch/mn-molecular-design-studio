import json
import os
from pathlib import Path
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request

base = "http://127.0.0.1:18766/api/v1"
state = Path(os.environ.get("MDS_TEACHING_BASE", "/home/user/programs/deployments/mn-molecular-design-studio/student-a82b05502283")) / "teaching-state"
credentials = json.loads((state / "credentials.json").read_text())
checks = {}

def request(path, data=None, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    operation = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None, headers=headers)
    try:
        with urllib.request.urlopen(operation, timeout=30) as response:
            raw = response.read()
            return response.status, json.loads(raw) if response.headers.get_content_type() == "application/json" else raw
    except urllib.error.HTTPError as error:
        return error.code, json.loads(error.read())

def require(code, expected, label):
    if code != expected:
        raise AssertionError(label + ": HTTP " + str(code))
    checks[label] = True

require(request("/molecules/groups")[0], 401, "anonymous_access_denied")
tokens = []
for account in credentials["accounts"]:
    password = account.get("password") or account["temporary_password"]
    code, login = request("/auth/login", {"username": account["username"], "password": password})
    require(code, 200, account["username"] + "_signed_in")
    token = login["access_token"]
    if login["user"]["must_change_password"]:
        require(request("/molecules/groups", token=token)[0], 403, account["username"] + "_temporary_password_restricted")
        new_password = secrets.token_urlsafe(24)
        require(request("/auth/password", {"new_password": new_password}, token)[0], 200,
                account["username"] + "_password_changed")
        require(request("/auth/me", token=token)[0], 401, account["username"] + "_old_session_revoked")
        account["password"] = new_password
        account.pop("temporary_password", None)
        (state / "credentials.json").write_text(json.dumps(credentials, indent=2) + "\n")
        code, login = request("/auth/login", {"username": account["username"], "password": new_password})
        require(code, 200, account["username"] + "_new_password_signed_in")
        token = login["access_token"]
    code, identity = request("/auth/me", token=token)
    require(code, 200, account["username"] + "_authenticated")
    assert identity.get("development_mode") is False
    assert identity["username"] == account["username"]
    tokens.append(token)
assert len(set(tokens)) == 3
instructor, first, second = tokens
require(request("/admin/users", token=first)[0], 403, "student_admin_access_denied")
code, imported = request("/molecules/imports", {"method": "smiles", "text": "CCCO private_teaching_propanol",
                                                "name": "TEACHING PRIVATE - first student"}, first)
require(code, 201, "student_private_import")
molecule = imported["molecule_ids"][0]
require(request("/molecules/" + molecule, token=second)[0], 404, "other_student_private_molecule_denied")
code, exported = request("/molecules/exports", {"molecule_ids": [molecule], "format": "CSV"}, first)
require(code, 201, "student_private_export")
download = exported["download_url"].removeprefix("/api/v1")
require(request(download, token=first)[0], 200, "owner_download_allowed")
require(request(download, token=second)[0], 404, "other_student_download_denied")
code, rows = request("/molecules?limit=250", token=first)
require(code, 200, "shared_classroom_visible")
items = rows["items"]
structured = next(row for row in items if row.get("representations") or row.get("structures"))
code, record = request("/molecules/" + structured["id"], token=first)
require(code, 200, "student_can_open_shared_structure")
structure = (record.get("representations") or record["structures"])[0]
context = structure.get("context") or {}
model = next((context.get(key) for key in ("model_id", "model_index", "model") if context.get(key) is not None), structure["id"])
chains = [component.get("chain") for component in record["components"] if component.get("type") == "protein" and component.get("chain")]
payload = {"schema_version": 1, "workflow": "analysis.sequence_liability", "project_id": credentials["project_id"],
           "database_source": {"molecule_id": record["id"], "group_id": structure["group_id"],
               "structure_id": structure["id"], "model_id": str(model), "binder_chains": chains, "target_chains": []},
           "parameters": {}, "resources": {"cpu_cores": 1, "gpu_device": "none"}}
code, validation = request("/workflows/validate", payload, first)
require(code, 200, "native_analysis_validated")
code, submission = request("/workflows", payload, first)
require(code, 202, "native_analysis_submitted")
code, repeated = request("/workflows", payload, second)
require(code, 202, "shared_scientific_request_replayed")
assert submission["job"]["run_id"] == repeated["job"]["run_id"]
run = submission["job"]["run_id"]
for attempt in range(90):
    code, page = request("/jobs?task_group=analysis&limit=100", token=first)
    require(code, 200, "student_job_visibility")
    job = next((item for item in page["items"] if item["run_id"] == run), None)
    if job and job["status"] in {"completed", "succeeded", "failed", "error", "cancelled"}:
        assert job["status"] in {"completed", "succeeded"}, job["status"]
        checks["real_native_analysis_completed"] = True
        break
    time.sleep(1)
else:
    raise AssertionError("Native analysis did not reach a terminal state within 90 seconds.")
code, replayed = request("/workflows", payload, second)
require(code, 202, "post_ingestion_scientific_request_replayed")
assert replayed["job"]["run_id"] == run
code, page = request("/jobs?task_group=analysis&limit=100", token=first)
assert len(page["items"]) == 1
checks["one_analysis_job_after_role_enrichment"] = True
result = {"pilot_url": "http://127.0.0.1:18502", "checks": checks, "checks_passed": len(checks),
          "analysis_run_id": run, "production_modified": False, "scientific_scope": "one real native CPU assessment, not GPU prediction validation"}
Path("/tmp/mds-student-readiness/pilot-acceptance.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))

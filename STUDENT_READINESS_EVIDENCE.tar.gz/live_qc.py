import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

source, output = map(Path, sys.argv[1:3])
output.mkdir(mode=0o700)
image = subprocess.run(["docker", "image", "inspect", "--format", "{{.Id}}", "mn-protein-qc:1.0.0"], capture_output=True, text=True)
if image.returncode:
    (output / "receipt.json").write_text(json.dumps({"status": "unavailable", "image": "mn-protein-qc:1.0.0",
        "download_attempted": False, "scientific_inference": False, "production_modified": False}) + "\n")
    print("QC image unavailable; no download attempted")
    raise SystemExit(2)
image = image.stdout.strip()
security = json.loads(subprocess.check_output(["docker", "info", "--format", "{{json .SecurityOptions}}"], text=True))
user = "0:0" if "name=rootless" in security else f"{os.getuid()}:{os.getgid()}"
structure = source / "tests/fixtures/pdl1_p4_ca.pdb"
amino_acids = dict(pair.split(":") for pair in "ALA:A ARG:R ASN:N ASP:D CYS:C GLN:Q GLU:E GLY:G HIS:H ILE:I LEU:L LYS:K MET:M PHE:F PRO:P SER:S THR:T TRP:W TYR:Y VAL:V".split())
sequence = "".join(amino_acids[line[17:20].strip()] for line in structure.read_text().splitlines()
    if line.startswith("ATOM") and line[21] == "B" and line[12:16].strip() == "CA")
module = source / "mn_molecular_design_studio/engine/workflow_engine/workflows"
receipts = []
for tool in ("sequence_qc", "biotite_interface", "interface_clustering"):
    work = output / tool
    work.mkdir(mode=0o700)
    shutil.copyfile(structure, work / "complex.pdb")
    manifest = {"schema": "studio.qc.v1", "tool": tool, "items": [
        {"id": f"item_{index:06d}", "candidate_id": f"teaching-{index}", "sequence": sequence,
         "structure": "/work/complex.pdb", "binder_chains": ["B"], "target_chains": ["A"], "target_key": "same-retained-example"}
        for index in range(2)], "settings": {"workers": 1, "ph": 7.4, "similarity_threshold": 0.5}, "output": "/work/output"}
    (work / "manifest.json").write_text(json.dumps(manifest))
    command = ["docker", "run", "--rm", "--pull=never", "--runtime=runc", "--network=none", "--read-only",
               "--cap-drop=ALL", "--security-opt=no-new-privileges", "--memory=2g", "--cpus=1", "--pids-limit=128",
               "--user", user, "--tmpfs", "/tmp:rw,nosuid,nodev,size=512m", "--workdir", "/work",
               "--mount", f"type=bind,src={work},dst=/work", "--mount", f"type=bind,src={module},dst=/opt/studio-qc,readonly",
               "--env", "HOME=/tmp", "--env", "OPENBLAS_NUM_THREADS=1", "--env", "OMP_NUM_THREADS=1",
               "--entrypoint", "python3", image, "/opt/studio-qc/quality_runner.py", "--manifest", "/work/manifest.json"]
    result = subprocess.run(command, capture_output=True, text=True, timeout=180)
    (work / "stdout.log").write_text(result.stdout)
    (work / "stderr.log").write_text(result.stderr)
    status_path = work / "output/batch_status.json"
    status = json.loads(status_path.read_text()) if status_path.is_file() else {}
    passed = result.returncode == 0 and status.get("finished") == 2 and all(row["status"] == "completed" for row in status.get("items", []))
    receipts.append({"tool": tool, "exit_code": result.returncode, "passed": passed, "command": command,
                     "completed_items": sum(row.get("status") == "completed" for row in status.get("items", []))})
receipt = {"image_id": image, "fixture_sha256": hashlib.sha256(structure.read_bytes()).hexdigest(),
           "host": os.uname().nodename, "tools": receipts, "production_modified": False,
           "scientific_scope": "real CPU container calculations on one retained fixture; not GPU prediction validation"}
(output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"host": receipt["host"], "tools": [{key: row[key] for key in ("tool", "passed", "completed_items")} for row in receipts]}))
raise SystemExit(0 if all(row["passed"] for row in receipts) else 1)

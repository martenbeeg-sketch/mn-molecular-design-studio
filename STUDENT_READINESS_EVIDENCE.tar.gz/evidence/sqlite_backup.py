#!/usr/bin/env python3
"""Make and validate a read-only-source SQLite backup.

Usage:
  backup.py sqlite --source live.sqlite3 --destination backup.sqlite3
  backup.py verify --database backup.sqlite3

The destination must be a new file in an existing, non-symlink directory.
SQLite's backup API reads the source in mode=ro, including committed WAL data.
The source is never opened for writing. A supervising process enforces a hard
deadline so a held SQLite lock cannot leave the command waiting indefinitely.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing
import os
import sqlite3
import stat
import sys
import time
from pathlib import Path
from typing import Any


DEFAULT_BUSY_TIMEOUT_MS = 3_000
DEFAULT_DEADLINE_SECONDS = 120.0
MAX_BUSY_TIMEOUT_MS = 30_000
MAX_DEADLINE_SECONDS = 600.0
BACKUP_PAGES = 256
BACKUP_SLEEP_SECONDS = 0.05


class BackupError(Exception):
    """Expected operational failure with a concise CLI message."""


class BackupDeadlineExceeded(BackupError):
    pass


def _absolute_path(raw: str, *, label: str) -> Path:
    path = Path(raw).expanduser()
    if ".." in path.parts:
        raise BackupError(f"{label} path may not contain '..': {raw}")
    return Path(os.path.abspath(path))


def _check_components(path: Path, *, allow_missing_leaf: bool, label: str) -> None:
    """Reject symlinks in every existing component, including a dangling leaf."""
    parts = path.parts
    current = Path(parts[0])
    for index, part in enumerate(parts[1:], start=1):
        current = current / part
        is_leaf = index == len(parts) - 1
        try:
            info = current.lstat()
        except FileNotFoundError:
            if is_leaf and allow_missing_leaf:
                continue
            raise BackupError(f"{label} path does not exist: {current}") from None
        if stat.S_ISLNK(info.st_mode):
            raise BackupError(f"{label} path contains a symlink: {current}")
        if not is_leaf and not stat.S_ISDIR(info.st_mode):
            raise BackupError(f"{label} parent is not a directory: {current}")


def _source_path(raw: str) -> Path:
    path = _absolute_path(raw, label="source")
    _check_components(path, allow_missing_leaf=False, label="source")
    if not path.is_file():
        raise BackupError(f"source is not a regular file: {path}")
    # SQLite can consult these siblings while reading a WAL database. Do not
    # follow attacker-controlled sidecar symlinks or special files.
    for suffix in ("-wal", "-shm", "-journal"):
        sidecar = Path(str(path) + suffix)
        try:
            info = sidecar.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise BackupError(f"source sidecar is not a regular file: {sidecar}")
    return path


def _destination_path(raw: str, source: Path) -> Path:
    path = _absolute_path(raw, label="destination")
    if path == source:
        raise BackupError("source and destination are the same path")
    _check_components(path.parent, allow_missing_leaf=False, label="destination parent")
    if not path.parent.is_dir():
        raise BackupError(f"destination parent is not a directory: {path.parent}")
    try:
        path.lstat()
    except FileNotFoundError:
        pass
    else:
        try:
            if os.path.samefile(path, source):
                raise BackupError("source and destination refer to the same file")
        except FileNotFoundError:
            pass
        raise BackupError(f"destination already exists: {path}")
    for suffix in ("-wal", "-shm", "-journal"):
        sidecar = Path(str(path) + suffix)
        try:
            sidecar.lstat()
        except FileNotFoundError:
            continue
        raise BackupError(f"destination sidecar already exists: {sidecar}")
    return path


def _readonly_uri(path: Path) -> str:
    return path.as_uri() + "?mode=ro"


def _connect_readonly(path: Path, busy_timeout_ms: int) -> sqlite3.Connection:
    connection = sqlite3.connect(
        _readonly_uri(path), uri=True, timeout=0.0, isolation_level=None
    )
    connection.execute(f"PRAGMA busy_timeout={int(busy_timeout_ms)}")
    return connection


def _backup_worker(
    source_name: str,
    destination_name: str,
    busy_timeout_ms: int,
    deadline: float,
    result_pipe: Any,
) -> None:
    """Child worker. The parent kills this process if the hard deadline passes."""
    source = Path(source_name)
    destination = Path(destination_name)
    source_connection: sqlite3.Connection | None = None
    destination_connection: sqlite3.Connection | None = None
    try:
        source_connection = _connect_readonly(source, busy_timeout_ms)
        source_user_version = int(
            source_connection.execute("PRAGMA user_version").fetchone()[0]
        )
        destination_connection = sqlite3.connect(
            str(destination), timeout=0.0, isolation_level=None
        )

        def progress(_status: int, _remaining: int, _total: int) -> None:
            if time.monotonic() >= deadline:
                raise BackupDeadlineExceeded("backup deadline exceeded")

        source_connection.backup(
            destination_connection,
            pages=BACKUP_PAGES,
            progress=progress,
            sleep=BACKUP_SLEEP_SECONDS,
        )
        if time.monotonic() >= deadline:
            raise BackupDeadlineExceeded("backup deadline exceeded")
        post_user_version = int(
            source_connection.execute("PRAGMA user_version").fetchone()[0]
        )
        result_pipe.send(
            {
                "ok": True,
                "source_user_version_before": source_user_version,
                "source_user_version_after": post_user_version,
            }
        )
    except BaseException as exc:  # communicate SQLite errors to the supervisor
        try:
            result_pipe.send({"ok": False, "error": f"{type(exc).__name__}: {exc}"})
        except (BrokenPipeError, OSError):
            pass
    finally:
        if destination_connection is not None:
            destination_connection.close()
        if source_connection is not None:
            source_connection.close()
        result_pipe.close()


def _reserve_destination(path: Path) -> None:
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError:
        raise BackupError(f"destination already exists: {path}") from None
    except OSError as exc:
        raise BackupError(f"cannot create destination {path}: {exc}") from None
    os.close(descriptor)


def _remove_output(path: Path) -> None:
    for candidate in (path, Path(str(path) + "-wal"), Path(str(path) + "-shm"), Path(str(path) + "-journal")):
        try:
            candidate.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            pass


def _run_supervised_backup(
    source: Path,
    destination: Path,
    *,
    busy_timeout_ms: int,
    deadline_seconds: float,
) -> dict[str, int]:
    context = multiprocessing.get_context("fork" if "fork" in multiprocessing.get_all_start_methods() else "spawn")
    parent_pipe, child_pipe = context.Pipe(duplex=False)
    deadline = time.monotonic() + deadline_seconds
    process = context.Process(
        target=_backup_worker,
        args=(str(source), str(destination), busy_timeout_ms, deadline, child_pipe),
        daemon=True,
    )
    try:
        process.start()
        child_pipe.close()
        remaining = max(0.0, deadline - time.monotonic())
        if not parent_pipe.poll(remaining):
            process.terminate()
            process.join(timeout=1.0)
            if process.is_alive() and hasattr(process, "kill"):
                process.kill()
                process.join(timeout=1.0)
            raise BackupDeadlineExceeded(
                f"backup exceeded deadline of {deadline_seconds:g} seconds"
            )
        result = parent_pipe.recv()
        process.join(timeout=1.0)
        if process.is_alive():
            process.terminate()
            process.join(timeout=1.0)
        if not result.get("ok"):
            raise BackupError(result.get("error", "backup worker failed"))
        if process.exitcode not in (0, None):
            raise BackupError(f"backup worker exited with status {process.exitcode}")
        return {
            "source_user_version_before": int(result["source_user_version_before"]),
            "source_user_version_after": int(result["source_user_version_after"]),
        }
    except (EOFError, OSError) as exc:
        raise BackupError(f"backup worker failed: {exc}") from None
    finally:
        parent_pipe.close()
        try:
            child_pipe.close()
        except OSError:
            pass
        if process.pid is not None and process.is_alive():
            process.terminate()
            process.join(timeout=1.0)


def _foreign_key_result(connection: sqlite3.Connection) -> dict[str, Any]:
    rows = connection.execute("PRAGMA foreign_key_check").fetchall()
    violations = [
        {"table": row[0], "rowid": row[1], "parent": row[2], "fkid": row[3]}
        for row in rows
    ]
    return {"ok": not violations, "violation_count": len(violations), "violations": violations}


def _schema(connection: sqlite3.Connection) -> list[dict[str, str | None]]:
    rows = connection.execute(
        "SELECT type, name, tbl_name, sql FROM sqlite_schema "
        "WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name"
    ).fetchall()
    return [
        {"type": row[0], "name": row[1], "table": row[2], "sql": row[3]}
        for row in rows
    ]


def _validate_database(path: Path, busy_timeout_ms: int) -> dict[str, Any]:
    connection: sqlite3.Connection | None = None
    try:
        connection = _connect_readonly(path, busy_timeout_ms)
        integrity_rows = [str(row[0]) for row in connection.execute("PRAGMA integrity_check")]
        foreign_keys = _foreign_key_result(connection)
        schema = _schema(connection)
        if integrity_rows != ["ok"]:
            raise BackupError("integrity_check failed: " + "; ".join(integrity_rows))
        if not foreign_keys["ok"]:
            raise BackupError(
                f"foreign_key_check found {foreign_keys['violation_count']} violation(s)"
            )
        return {
            "integrity_check": {"ok": True, "result": integrity_rows},
            "foreign_key_check": foreign_keys,
            "schema": schema,
        }
    except sqlite3.Error as exc:
        raise BackupError(f"SQLite validation failed for {path}: {exc}") from None
    finally:
        if connection is not None:
            connection.close()


def _file_digest(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            size += len(block)
            digest.update(block)
    return size, digest.hexdigest()


def create_backup(
    source_raw: str,
    destination_raw: str,
    *,
    busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS,
    deadline_seconds: float = DEFAULT_DEADLINE_SECONDS,
) -> dict[str, Any]:
    source = _source_path(source_raw)
    destination = _destination_path(destination_raw, source)
    user_versions: dict[str, int] | None = None
    reserved = False
    try:
        _reserve_destination(destination)
        reserved = True
        user_versions = _run_supervised_backup(
            source,
            destination,
            busy_timeout_ms=busy_timeout_ms,
            deadline_seconds=deadline_seconds,
        )
        validation = _validate_database(destination, busy_timeout_ms)
        size, digest = _file_digest(destination)
        return {
            "operation": "sqlite_backup",
            "source": str(source),
            "destination": str(destination),
            "source_user_version_before": user_versions["source_user_version_before"],
            "source_user_version_after": user_versions["source_user_version_after"],
            "size_bytes": size,
            "sha256": digest,
            **validation,
        }
    except Exception:
        if reserved:
            _remove_output(destination)
        raise


def verify_database(database_raw: str, *, busy_timeout_ms: int = DEFAULT_BUSY_TIMEOUT_MS) -> dict[str, Any]:
    database = _source_path(database_raw)
    validation = _validate_database(database, busy_timeout_ms)
    size, digest = _file_digest(database)
    return {
        "operation": "sqlite_verify",
        "database": str(database),
        "size_bytes": size,
        "sha256": digest,
        **validation,
    }


def _bounded_options(args: argparse.Namespace) -> None:
    if not 1 <= args.busy_timeout_ms <= MAX_BUSY_TIMEOUT_MS:
        raise BackupError(
            f"--busy-timeout-ms must be between 1 and {MAX_BUSY_TIMEOUT_MS}"
        )
    if not 0.1 <= args.deadline_seconds <= MAX_DEADLINE_SECONDS:
        raise BackupError(
            f"--deadline-seconds must be between 0.1 and {MAX_DEADLINE_SECONDS:g}"
        )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Safely prepare or verify a SQLite backup.")
    subparsers = parser.add_subparsers(dest="command", required=True)
    sqlite_parser = subparsers.add_parser(
        "sqlite", help="copy a live SQLite database into a new destination file"
    )
    sqlite_parser.add_argument("--source", required=True, help="existing source database")
    sqlite_parser.add_argument("--destination", required=True, help="new output database path")
    sqlite_parser.add_argument(
        "--busy-timeout-ms", type=int, default=DEFAULT_BUSY_TIMEOUT_MS,
        help=f"SQLite lock wait per operation, 1..{MAX_BUSY_TIMEOUT_MS} ms (default {DEFAULT_BUSY_TIMEOUT_MS})",
    )
    sqlite_parser.add_argument(
        "--deadline-seconds", type=float, default=DEFAULT_DEADLINE_SECONDS,
        help=f"hard backup-copy limit, 0.1..{MAX_DEADLINE_SECONDS:g} seconds (default {DEFAULT_DEADLINE_SECONDS:g})",
    )
    verify_parser = subparsers.add_parser(
        "verify", help="run read-only integrity and foreign-key checks on a database copy"
    )
    verify_parser.add_argument("--database", required=True, help="database copy to validate")
    verify_parser.add_argument(
        "--busy-timeout-ms", type=int, default=DEFAULT_BUSY_TIMEOUT_MS,
        help=f"SQLite lock wait per operation, 1..{MAX_BUSY_TIMEOUT_MS} ms (default {DEFAULT_BUSY_TIMEOUT_MS})",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "sqlite":
            _bounded_options(args)
            result = create_backup(
                args.source,
                args.destination,
                busy_timeout_ms=args.busy_timeout_ms,
                deadline_seconds=args.deadline_seconds,
            )
        else:
            if not 1 <= args.busy_timeout_ms <= MAX_BUSY_TIMEOUT_MS:
                raise BackupError(
                    f"--busy-timeout-ms must be between 1 and {MAX_BUSY_TIMEOUT_MS}"
                )
            result = verify_database(args.database, busy_timeout_ms=args.busy_timeout_ms)
        print(json.dumps(result, sort_keys=True))
        return 0
    except (BackupError, sqlite3.Error, OSError) as exc:
        print(json.dumps({"error": str(exc)}, sort_keys=True), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

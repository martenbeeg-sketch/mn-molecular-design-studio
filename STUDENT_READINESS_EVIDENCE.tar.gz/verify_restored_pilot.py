import hashlib
import json
import os
from pathlib import Path
import sqlite3

state = Path("/state")
manifest = json.loads((state / "restore_manifest.json").read_text())
for row in manifest["files"]:
    path = state / row["path"]
    if "link" in row:
        assert path.is_symlink() and os.readlink(path) == row["link"]
    else:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"]
for relative in manifest["databases"]:
    connection = sqlite3.connect((state / relative).as_uri() + "?mode=ro", uri=True)
    assert connection.execute("PRAGMA integrity_check").fetchall() == [("ok",)]
    assert connection.execute("PRAGMA foreign_key_check").fetchall() == []
    connection.close()
review = json.loads((state / "review-acceptance.json").read_text())
assert review["stale_review_rejected"] and review["saved_native_evaluation_exported"]
assert json.loads((state / "teaching-shortlist.json").read_text())["records"][0]["evaluations"][0]["evaluation_id"] == review["evaluation_id"]
print(json.dumps({"isolated_restored_pilot_verified": True, "regular_files_and_links": len(manifest["files"]),
                  "databases": len(manifest["databases"]), "evaluation_identity_preserved": True,
                  "production_modified": False}))

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import subprocess
from datetime import datetime, timezone

base = Path(os.environ.get("MDS_TEACHING_BASE", "/home/user/programs/deployments/mn-molecular-design-studio/student-a82b05502283"))
state = base / "teaching-state"
destination = base / ("teaching-recovery-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"))
destination.mkdir(mode=0o700)
restore = destination / "restored-state"
restore.mkdir(mode=0o700)
spec = importlib.util.spec_from_file_location("sqlite_backup", "/tmp/mds-sqlite-backup.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)

def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()

def science():
    connection = sqlite3.connect((state / "home/database/molecular_library.sqlite3").as_uri() + "?mode=ro", uri=True)
    tables = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
              if not row[0].startswith("sqlite_") and row[0] not in {"molecule_evaluations", "molecule_metric_values"}]
    result = {}
    for table in tables:
        checksum = hashlib.sha256()
        count = 0
        for row in connection.execute('SELECT * FROM "' + table + '" ORDER BY rowid'):
            checksum.update(json.dumps(row, default=str, separators=(",", ":")).encode() + b"\n")
            count += 1
        result[table] = {"rows": count, "sha256": checksum.hexdigest()}
    connection.close()
    return result

subprocess.run(["docker", "stop", "--timeout", "25", "mds-teaching-pilot-20261111"], check=True)
try:
    before = science()
    databases = []
    for folder, directories, files in os.walk(state, followlinks=False):
        for name in files:
            path = Path(folder) / name
            if not path.is_symlink() and path.suffix in {".sqlite3", ".sqlite", ".db"}:
                with path.open("rb") as stream:
                    if stream.read(16) == b"SQLite format 3\x00":
                        databases.append(path.relative_to(state))
    ignored = {str(relative) + suffix for relative in databases for suffix in ("", "-wal", "-shm", "-journal")}
    for folder, directories, files in os.walk(state, followlinks=False):
        relative = Path(folder).relative_to(state)
        target = restore / relative
        target.mkdir(parents=True, exist_ok=True, mode=0o700)
        for name in list(directories):
            path = Path(folder) / name
            if path.is_symlink():
                (target / name).symlink_to(os.readlink(path))
                directories.remove(name)
        for name in files:
            path = Path(folder) / name
            if str(relative / name) in ignored:
                continue
            if path.is_symlink():
                (target / name).symlink_to(os.readlink(path))
            else:
                shutil.copyfile(path, target / name)
                (target / name).chmod(0o600)
    database_results = {}
    for relative in databases:
        helper.create_backup(str(state / relative), str(restore / relative), deadline_seconds=120)
        helper.verify_database(str(restore / relative))
        database_results[str(relative)] = "integrity and foreign-key checks passed"
    files = []
    for folder, directories, names in os.walk(restore, followlinks=False):
        for name in list(directories) + names:
            path = Path(folder) / name
            if path.is_symlink():
                files.append({"path": str(path.relative_to(restore)), "link": os.readlink(path)})
                if name in directories:
                    directories.remove(name)
            elif path.is_file():
                files.append({"path": str(path.relative_to(restore)), "sha256": digest(path)})
    (restore / "restore_manifest.json").write_text(json.dumps({"files": files, "databases": database_results}, indent=2) + "\n")
    (destination / "scientific-baseline.json").write_text(json.dumps(before, indent=2) + "\n")
    (base / "latest-teaching-recovery.txt").write_text(str(destination) + "\n")
finally:
    subprocess.run(["docker", "start", "mds-teaching-pilot-20261111"], check=True)
after = science()
assert before == after
receipt = {"scope": "complete isolated teaching pilot only, not production", "files": len(files),
           "databases": len(database_results), "quiet_point": True, "scientific_tables_unchanged": before == after,
           "restored_state": str(restore), "production_modified": False}
(destination / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))

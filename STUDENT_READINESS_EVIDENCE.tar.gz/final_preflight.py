import hashlib
import json
from pathlib import Path
import shlex
import socket
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone

home = Path.home()
app = home / ".local/share/mn-molecular-design-studio"
backup = home / "mn-mds-recovery" / sys.argv[1]
record = json.loads((backup / "receipt.json").read_text())
summary = {"host": socket.gethostname(), "captured_at": datetime.now(timezone.utc).isoformat(),
           "online_database_backups": {}, "complete_production_recovery_set": False, "production_services": {}}
for relative, result in record["databases"].items():
    summary["online_database_backups"][relative] = {
        "size_bytes": result["backup"]["size_bytes"], "sha256": result["backup"]["sha256"],
        "restored_integrity_ok": result["restore"]["integrity_check"]["ok"],
        "restored_foreign_keys_ok": result["restore"]["foreign_key_check"]["ok"]}
for unit in ("studio-api.service", "studio-agent.service", "studio-ui.service"):
    output = subprocess.check_output(["systemctl", "--user", "show", unit,
        "-p", "MainPID", "-p", "ActiveState", "-p", "WorkingDirectory"], text=True)
    summary["production_services"][unit] = dict(line.split("=", 1) for line in output.splitlines() if "=" in line)
environment = subprocess.check_output(["systemctl", "--user", "show", "studio-api.service", "-p", "Environment", "--value"], text=True)
summary["production_authentication_mode"] = next((value.split("=", 1)[1] for value in shlex.split(environment)
    if value.startswith("MN_MOLECULAR_DESIGN_STUDIO_AUTH_MODE=")), "not explicitly configured")
for relative, query, name in [
    ("database/user_access.sqlite3", "SELECT COUNT(*) FROM users", "production_account_count"),
    ("api-requests.sqlite3", "SELECT COUNT(*) FROM requests WHERE kind='scientific'", "production_scientific_admission_count"),
]:
    connection = sqlite3.connect((app / relative).as_uri() + "?mode=ro", uri=True)
    summary[name] = connection.execute(query).fetchone()[0]
    connection.close()
print(json.dumps(summary, indent=2))

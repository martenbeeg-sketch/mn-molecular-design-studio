import json
import os
from pathlib import Path
import urllib.request

state = Path(os.environ["MDS_TEACHING_BASE"]) / "teaching-state"
credentials = json.loads((state / "credentials.json").read_text())
account = credentials["accounts"][2]
root = "http://127.0.0.1:18766/api/v1"

def request(path, payload=None, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    operation = urllib.request.Request(root + path, data=json.dumps(payload).encode() if payload is not None else None, headers=headers)
    with urllib.request.urlopen(operation, timeout=30) as response:
        return response.status, json.load(response)

code, login = request("/auth/login", {"username": account["username"], "password": account["password"]})
assert code == 200
token = login["access_token"]
manifest = json.loads(next((state / "home/scientific-admission/inputs").rglob("complex_analysis_source.json")).read_text())
selection = {key: manifest[key] for key in ["molecule_id", "structure_id", "group_id", "model_id", "binder_chains", "target_chains"]}
payload = {"schema_version": 1, "workflow": "analysis.sequence_liability", "project_id": credentials["project_id"],
           "database_source": selection, "parameters": {}, "resources": {"cpu_cores": 1, "gpu_device": "none"}}
code, result = request("/workflows", payload, token)
assert code == 202
expected = json.loads(Path("/tmp/mds-student-readiness/pilot-acceptance.json").read_text())["analysis_run_id"]
assert result["job"]["run_id"] == expected
code, jobs = request("/jobs?task_group=analysis&limit=100", token=token)
assert len(jobs["items"]) == 1 and jobs["items"][0]["status"] == "completed"
receipt = {"native_assessment_reused_after_restart": True, "same_run_id": expected,
           "analysis_job_count": 1, "production_modified": False}
Path("/tmp/mds-student-readiness/pilot-restart-verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))

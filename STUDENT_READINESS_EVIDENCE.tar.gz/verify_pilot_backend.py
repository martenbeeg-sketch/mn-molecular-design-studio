import json
from pathlib import Path
from mn_molecular_design_studio import auth
from mn_molecular_design_studio.molecular_database import MolecularDatabase, ReviewConflictError
from mn_molecular_design_studio.complex_analysis_design_review import design_review_page
from mn_molecular_design_studio.complex_analysis_shortlist_export import build_shortlist_manifest, manifest_csv

credentials = json.loads(Path("/state/credentials.json").read_text())
account = credentials["accounts"][1]
user = auth.authenticate(account["username"], account["password"])[0]
database = MolecularDatabase()
with database.connection() as connection:
    rows = connection.execute("SELECT molecule_id,group_id,run_id,context FROM molecule_observations").fetchall()
assert len(rows) == 1
observation = rows[0]
context = json.loads(observation["context"])
identity = {"source_kind": "database", "subject_id": observation["molecule_id"], "structure_ref": context["source_structure_id"]}
original = database.get_complex_review(user, **identity)
first = database.save_complex_review(user, **identity, status="Reviewed",
    note="Teaching-only review of native sequence-liability evidence; not an affinity claim.", expected_revision=original["revision"])
second = database.save_complex_review(user, **identity, status="Reviewed",
    note="Updated teaching rationale; preserve scientific evidence separately.", expected_revision=first["revision"])
try:
    database.save_complex_review(user, **identity, status="Reviewed", note="Stale teaching edit", expected_revision=first["revision"])
except ReviewConflictError:
    rejected = True
else:
    raise AssertionError("Stale teaching edit was accepted")
page = design_review_page(database, user, [observation["group_id"]])
sample = next(row for row in page["items"] if row["structure_id"] == context["source_structure_id"])
manifest = build_shortlist_manifest([sample])
Path("/state/teaching-shortlist.json").write_text(json.dumps(manifest, indent=2))
Path("/state/teaching-shortlist.csv").write_bytes(manifest_csv(manifest))
entry = manifest["records"][0]["evaluations"][0]
assert entry["run_id"] == observation["run_id"]
assert entry["method_version"] == "studio.sequence-liabilities.v1"
assert entry["structure_sha256"] == context["source_structure_digest"]
assert entry["evaluation_id"]
result = {"stale_review_rejected": rejected, "newer_rationale_preserved": database.get_complex_review(user, **identity)["note"] == second["note"],
          "saved_native_evaluation_exported": True, "evaluation_id": entry["evaluation_id"], "method_version": entry["method_version"],
          "run_id": entry["run_id"], "structure_sha256": entry["structure_sha256"], "analysis_observations": 1,
          "json_export_bytes": Path("/state/teaching-shortlist.json").stat().st_size, "csv_export_bytes": Path("/state/teaching-shortlist.csv").stat().st_size}
Path("/state/review-acceptance.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))

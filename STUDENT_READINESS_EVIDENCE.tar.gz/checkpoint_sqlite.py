import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import sys
from datetime import datetime, timezone

stamp = sys.argv[1]
home = Path.home()
app = home / ".local/share/mn-molecular-design-studio"
destination = home / "mn-mds-recovery" / stamp
destination.mkdir(mode=0o700)
spec = importlib.util.spec_from_file_location("sqlite_backup", sys.argv[2])
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
record = {"host": socket.gethostname(), "started_at": datetime.now(timezone.utc).isoformat(),
          "scope": "online per-Database snapshots and isolated SQLite restores only",
          "coordinated_quiet_point": False, "complete_scientific_file_recovery_set": False,
          "production_modified": False, "databases": {}}
for relative in ["database/molecular_library.sqlite3", "database/user_access.sqlite3",
                 "database/job_catalog.sqlite3", "cluster/replication.sqlite3",
                 "cluster/coordinator.sqlite3", "api-requests.sqlite3"]:
    source = app / relative
    snapshot = destination / "snapshots" / relative
    restored = destination / "isolated-restore" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    restored.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    backup = helper.create_backup(str(source), str(snapshot), deadline_seconds=600)
    shutil.copyfile(snapshot, restored)
    snapshot.chmod(0o600)
    restored.chmod(0o600)
    validation = helper.verify_database(str(restored))
    record["databases"][relative] = {"backup": backup, "restore": validation}
    (destination / "receipt.json").write_text(json.dumps(record, indent=2) + "\n")
    (destination / "receipt.json").chmod(0o600)
    print(json.dumps({"host": socket.gethostname(), "database": relative, "restore_verified": True}), flush=True)
record["finished_at"] = datetime.now(timezone.utc).isoformat()
(destination / "receipt.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"host": socket.gethostname(), "completed": len(record["databases"]), "receipt": str(destination / "receipt.json")}), flush=True)

import json
import os
from pathlib import Path
import subprocess

base = Path(os.environ.get("MDS_TEACHING_BASE", "/home/user/programs/deployments/mn-molecular-design-studio/student-a82b05502283"))
source = Path(os.environ.get("MDS_TEACHING_SOURCE", str(base / "source")))
security = json.loads(subprocess.check_output(["docker", "info", "--format", "{{json .SecurityOptions}}"], text=True))
rootless = "name=rootless" in security
user = "0:0" if rootless else f"{os.getuid()}:{os.getgid()}"
command = ["docker", "run", "-d", "--name", "mds-teaching-pilot-20261111", "--pull=never", "--runtime=runc",
           "--network", "none", "--read-only", "--cap-drop=ALL",
           "--security-opt=no-new-privileges", "--pids-limit=512", "--memory=8g", "--cpus=4", "--user", user,
           "--tmpfs", "/tmp:rw,nosuid,nodev,size=2g", "--mount", f"type=bind,src={source},dst=/source,readonly",
           "--mount", "type=bind,src=/home/user/mambaforge,dst=/home/user/mambaforge,readonly",
           "--mount", f"type=bind,src={base}/teaching-state,dst=/state"]
environment = {"HOME": "/state/unix-home", "XDG_CACHE_HOME": "/state/cache", "PYTHONDONTWRITEBYTECODE": "1",
               "PYTHONPATH": "/source", "MN_MOLECULAR_DESIGN_STUDIO_HOME": "/state/home",
               "MN_MOLECULAR_DESIGN_STUDIO_APP_HOME": "/state/home", "MN_MOLECULAR_DESIGN_STUDIO_RUN_DIR": "/state/runs",
               "MN_MOLECULAR_DESIGN_STUDIO_REFERENCE_DIR": "/state/references", "MDS_CLUSTER_HOME": "/state/home/cluster",
               "MN_MOLECULAR_DESIGN_STUDIO_AUTH_MODE": "production", "MN_MOLECULAR_DESIGN_STUDIO_SCHEDULER_MODE": "local",
               "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1",
               "STREAMLIT_BROWSER_GATHER_USAGE_STATS": "false", "STREAMLIT_CLIENT_TOOLBAR_MODE": "viewer"}
for name, value in environment.items():
    command.extend(["--env", name + "=" + value])
command.extend(["--entrypoint", "/home/user/mambaforge/envs/mn-molecular-design-studio/bin/python",
                "sha256:b3366c6f1e14ffe3d0962938440503a3126685645d7f9a3fee0e81db6b57691a",
                "/source/scripts/teaching_sandbox.py"])
identifier = subprocess.check_output(command, text=True).strip()
(base / "pilot-launch.json").write_text(json.dumps({"container": identifier, "command": command,
    "rootless_daemon": rootless, "host_user": os.getuid(), "production_modified": False}, indent=2) + "\n")
print(json.dumps({"container": identifier, "rootless_daemon": rootless, "container_user": user}))

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone

revision, archive_digest, bundle_digest = sys.argv[1:4]
assert len(revision) == 40 and all(char in "0123456789abcdef" for char in revision)
base = Path.home() / "programs/deployments/mn-molecular-design-studio" / ("sol-" + revision[:12])
repository = Path.home() / "programs/git-projects/mn-molecular-design-studio"
source = base / "source"
assert not source.exists(), "Refusing to overwrite an existing release source."

def git(*arguments):
    return subprocess.check_output(["git", "-C", str(repository), *arguments], text=True).strip()

def services():
    result = {}
    for service in ("studio-api.service", "studio-agent.service", "studio-ui.service"):
        fields = subprocess.run(["systemctl", "--user", "show", service, "-p", "MainPID", "-p", "ActiveState"],
                                text=True, capture_output=True, check=True).stdout
        result[service] = dict(line.split("=", 1) for line in fields.splitlines() if "=" in line)
        process = result[service]["MainPID"]
        if process != "0":
            result[service]["source"] = os.readlink("/proc/" + process + "/cwd")
    return result

before = services()
head_before = git("rev-parse", "HEAD")
status_before = git("status", "--porcelain")
for name, expected in (("source.tar.gz", archive_digest), ("source.bundle", bundle_digest)):
    assert hashlib.sha256((base / name).read_bytes()).hexdigest() == expected, name + " digest mismatch"
subprocess.run(["git", "-C", str(repository), "bundle", "verify", str(base / "source.bundle")], check=True)
subprocess.run(["git", "-C", str(repository), "fetch", "--no-tags", str(base / "source.bundle"), "HEAD"], check=True)
assert git("rev-parse", "FETCH_HEAD") == revision
source.mkdir(mode=0o700)
with tarfile.open(base / "source.tar.gz", "r:gz") as archive:
    for member in archive.getmembers():
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and ".." not in path.parts
        assert member.isfile() or member.isdir(), "Non-regular archive member refused"
    archive.extractall(source, filter="data")
with (base / "source-check.log").open("w") as output:
    subprocess.run(["sha256sum", "--check", str(base / "app-test-source.sha256")], cwd=source,
                   stdout=output, stderr=subprocess.STDOUT, check=True)
test_result = None
if "--stage-only" not in sys.argv[4:]:
    python = str(Path.home() / "programs/miniforge3/envs/mn-molecular-design-studio/bin/python")
    environment = dict(os.environ, MDS_TEST_PYTHON=python)
    modules = ["test_post_phase2_release", "test_api_integrations", "test_assessment_planning_audit",
               "test_assessment_submission_audit", "test_assessment_job_index_audit", "test_complex_analysis",
               "test_complex_analysis_design_review", "test_molecular_database_peer", "test_peer_workstations",
               "test_review_concurrency_audit", "test_complex_analysis_dashboard"]
    junit = Path(tempfile.mkdtemp(prefix="mds-sol-junit-")) / "regressions.xml"
    with (base / "remote-regressions.log").open("w") as output:
        test_result = subprocess.run(["bash", "scripts/test_release_isolated.sh", "-q", "-rs",
            "--junitxml=" + str(junit),
            *["tests/" + name + ".py" for name in modules]], cwd=source, env=environment,
            stdout=output, stderr=subprocess.STDOUT).returncode
    if junit.is_file():
        (base / "remote-regressions.xml").write_bytes(junit.read_bytes())
after = services()
assert before == after, "A production service changed during staging; investigate."
assert git("rev-parse", "HEAD") == head_before
assert git("status", "--porcelain") == status_before
receipt = {"captured_at": datetime.now(timezone.utc).isoformat(), "host": os.uname().nodename,
           "revision": revision, "archive_sha256": archive_digest, "bundle_sha256": bundle_digest,
           "source": str(source), "mode": "staged_only_not_activated", "services_before": before,
           "services_after": after, "development_checkout_unchanged": True,
           "authentication_changed": False, "scientific_data_changed": False,
           "regression_exit_code": test_result}
(base / "staging-receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps(receipt, sort_keys=True))
if test_result:
    raise SystemExit(test_result)

import hashlib
import json
from pathlib import Path
import sqlite3
import time

from mn_molecular_design_studio import evaluations

path = Path("/tmp/mds-release-fixes/migration/molecular_library.sqlite3")
connection = sqlite3.connect(path)
connection.row_factory = sqlite3.Row
connection.execute("PRAGMA foreign_keys=ON")


def rows_digest(query):
    digest = hashlib.sha256()
    count = 0
    for row in connection.execute(query):
        digest.update(json.dumps(tuple(row), default=str, separators=(",", ":")).encode())
        digest.update(b"\n")
        count += 1
    return {"rows": count, "sha256": digest.hexdigest()}


def raw_state():
    names = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
             if not row[0].startswith("sqlite_") and row[0] not in {"molecule_evaluations", "molecule_metric_values"}]
    return {name: rows_digest('SELECT * FROM "' + name + '" ORDER BY rowid') for name in names}


started = time.monotonic()
before = raw_state()
identities = rows_digest("SELECT observation_id,json_extract(descriptor,'$.id') FROM molecule_evaluations ORDER BY observation_id")
versions_before = [tuple(row) for row in connection.execute("SELECT projection_version,COUNT(*) FROM molecule_evaluations GROUP BY projection_version")]
rebuilt, batches = 0, 0
evaluations.install_schema(connection)
with connection:
    while True:
        count = evaluations.rebuild_missing(connection, batch_size=500)
        if not count:
            break
        rebuilt += count
        batches += 1
after = raw_state()
identities_after = rows_digest("SELECT observation_id,json_extract(descriptor,'$.id') FROM molecule_evaluations ORDER BY observation_id")
integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
result = {"projection_version": evaluations.PROJECTION_VERSION, "versions_before": versions_before,
          "versions_after": [tuple(row) for row in connection.execute("SELECT projection_version,COUNT(*) FROM molecule_evaluations GROUP BY projection_version")],
          "rebuilt": rebuilt, "batches": batches, "raw_tables": before, "raw_tables_unchanged": before == after,
          "canonical_evaluation_ids_unchanged": identities == identities_after, "integrity_check": integrity,
          "elapsed_seconds": round(time.monotonic() - started, 2)}
print(json.dumps(result, indent=2, sort_keys=True))
connection.close()
assert result["raw_tables_unchanged"]
assert result["canonical_evaluation_ids_unchanged"]
assert integrity == "ok"
